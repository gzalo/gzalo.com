#include <8052.h>

//Pines del shift register 74x595 o 74x164 (sin latch), usados para controlar COLUMNAS - �nodos de leds
#define SHIFTREG_DATA P1_2
#define SHIFTREG_CLOCK P1_0
#define SHIFTREG_LATCH P1_1

//Datos de la imagen a mostrar (framebuffer)
__idata unsigned char matrixData[32];

//�ndice de fila actual
unsigned char rowCounter = 0;
//Salidas que se activan en cada fila (equivalente a ~(1<<i) pero m�s r�pido). El �ltimo valor es el correspondiente a "todas filas apagadas"
unsigned char rowVal[9] = {0b11111110,0b11111101,0b11111011,0b11110111,0b11101111,0b11011111,0b10111111,0b01111111,0b11111111};
//Puerto usado para elegir las filas
#define PORT_ROW P2
//Tiempo que cada fila est� prendida (en microsegundos)
#define US_PER_ROW 1000

//Pin para mostrar cuando est� atendiendo la interupci�n
#define DEBUG_PIN P1_7

//Funci�n que saca un byte por los shift registers (Primero bits menos significativos)
void shiftByte(unsigned char byte){
	SHIFTREG_DATA = byte&0x01;
	SHIFTREG_CLOCK = 1;
	SHIFTREG_CLOCK = 0;
	SHIFTREG_DATA = byte&0x02;
	SHIFTREG_CLOCK = 1;
	SHIFTREG_CLOCK = 0;
	SHIFTREG_DATA = byte&0x04;
	SHIFTREG_CLOCK = 1;
	SHIFTREG_CLOCK = 0;
	SHIFTREG_DATA = byte&0x08;
	SHIFTREG_CLOCK = 1;
	SHIFTREG_CLOCK = 0;
	SHIFTREG_DATA = byte&0x10;
	SHIFTREG_CLOCK = 1;
	SHIFTREG_CLOCK = 0;
	SHIFTREG_DATA = byte&0x20;
	SHIFTREG_CLOCK = 1;
	SHIFTREG_CLOCK = 0;
	SHIFTREG_DATA = byte&0x40;
	SHIFTREG_CLOCK = 1;
	SHIFTREG_CLOCK = 0;
	SHIFTREG_DATA = byte&0x80;
	SHIFTREG_CLOCK = 1;
	SHIFTREG_CLOCK = 0;
}

//Interrupci�n del timer0
void matrixIsr() __interrupt(TF0_VECTOR) __using(1){
	DEBUG_PIN = 1; //Mostrar que entramos a la interrupci�n
	
	TH0 = (65535 - 2*US_PER_ROW) >> 8; //Reiniciar el timer0
	TL0 = (65535 - 2*US_PER_ROW) & 0xFF;

	PORT_ROW = rowVal[8]; //Apagamos todas las filas
	
	shiftByte(matrixData[rowCounter*4+3]); //Mandamos todos los bytes correspondientes a los shift registers
	shiftByte(matrixData[rowCounter*4+2]);
	shiftByte(matrixData[rowCounter*4+1]);
	shiftByte(matrixData[rowCounter*4+0]);
	
	SHIFTREG_LATCH = 1; //"Actualizamos" la etapa de salida de los shift registers
	SHIFTREG_LATCH = 0;
	
	PORT_ROW = rowVal[rowCounter++]; //Activamos la fila correspondiente, pasamos a la pr�xima
	rowCounter&=7; //Solamente hay 8 filas, evitamos que se pase de 8
	
	DEBUG_PIN = 0;
}

void main(){
	//Timer0 en modo 16 bits, corriendo
	TMOD = T0_M0;
	TR0 = 1;
	
	//Habilitada interrupci�n del Timer0
	IE = 0x80;
	ET0 = 1;

	//Datos a mostrar en la matriz
	//H
	matrixData[0 ] = 0b10000001;
	matrixData[4 ] = 0b10000001;
	matrixData[8 ] = 0b10000001;
	matrixData[12] = 0b11111111;
	matrixData[16] = 0b10000001;
	matrixData[20] = 0b10000001;
	matrixData[24] = 0b10000001;
	matrixData[28] = 0b10000001;

	//O
	matrixData[ 1] = 0b01111110;
	matrixData[ 5] = 0b10000001;
	matrixData[ 9] = 0b10000001;
	matrixData[13] = 0b10000001;
	matrixData[17] = 0b10000001;
	matrixData[21] = 0b10000001;
	matrixData[25] = 0b10000001;
	matrixData[29] = 0b01111110;
	
	//L
	matrixData[2 ] = 0b10000000;
	matrixData[6 ] = 0b10000000;
	matrixData[10] = 0b10000000;
	matrixData[14] = 0b10000000;
	matrixData[18] = 0b10000000;
	matrixData[22] = 0b10000000;
	matrixData[26] = 0b10000000;
	matrixData[30] = 0b01111111;
		
	//A
	matrixData[3 ] = 0b00011000;
	matrixData[7 ] = 0b00100100;
	matrixData[11] = 0b01000010;
	matrixData[15] = 0b01000010;
	matrixData[19] = 0b01111110;
	matrixData[23] = 0b01000010;
	matrixData[27] = 0b01000010;
	matrixData[31] = 0b01000010;
	
	while(1);
}

