                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : free open source ANSI-C Compiler
                              3 ; Version 3.2.0 #8008 (Jul  6 2012) (MINGW32)
                              4 ; This file was generated Wed Jan 23 15:15:42 2013
                              5 ;--------------------------------------------------------
                              6 	.module 8052_megaMatrix
                              7 	.optsdcc -mmcs51 --model-small
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _main
                             13 	.globl _matrixIsr
                             14 	.globl _shiftByte
                             15 	.globl _TF2
                             16 	.globl _EXF2
                             17 	.globl _RCLK
                             18 	.globl _TCLK
                             19 	.globl _EXEN2
                             20 	.globl _TR2
                             21 	.globl _C_T2
                             22 	.globl _CP_RL2
                             23 	.globl _T2CON_7
                             24 	.globl _T2CON_6
                             25 	.globl _T2CON_5
                             26 	.globl _T2CON_4
                             27 	.globl _T2CON_3
                             28 	.globl _T2CON_2
                             29 	.globl _T2CON_1
                             30 	.globl _T2CON_0
                             31 	.globl _PT2
                             32 	.globl _ET2
                             33 	.globl _CY
                             34 	.globl _AC
                             35 	.globl _F0
                             36 	.globl _RS1
                             37 	.globl _RS0
                             38 	.globl _OV
                             39 	.globl _F1
                             40 	.globl _P
                             41 	.globl _PS
                             42 	.globl _PT1
                             43 	.globl _PX1
                             44 	.globl _PT0
                             45 	.globl _PX0
                             46 	.globl _RD
                             47 	.globl _WR
                             48 	.globl _T1
                             49 	.globl _T0
                             50 	.globl _INT1
                             51 	.globl _INT0
                             52 	.globl _TXD
                             53 	.globl _RXD
                             54 	.globl _P3_7
                             55 	.globl _P3_6
                             56 	.globl _P3_5
                             57 	.globl _P3_4
                             58 	.globl _P3_3
                             59 	.globl _P3_2
                             60 	.globl _P3_1
                             61 	.globl _P3_0
                             62 	.globl _EA
                             63 	.globl _ES
                             64 	.globl _ET1
                             65 	.globl _EX1
                             66 	.globl _ET0
                             67 	.globl _EX0
                             68 	.globl _P2_7
                             69 	.globl _P2_6
                             70 	.globl _P2_5
                             71 	.globl _P2_4
                             72 	.globl _P2_3
                             73 	.globl _P2_2
                             74 	.globl _P2_1
                             75 	.globl _P2_0
                             76 	.globl _SM0
                             77 	.globl _SM1
                             78 	.globl _SM2
                             79 	.globl _REN
                             80 	.globl _TB8
                             81 	.globl _RB8
                             82 	.globl _TI
                             83 	.globl _RI
                             84 	.globl _P1_7
                             85 	.globl _P1_6
                             86 	.globl _P1_5
                             87 	.globl _P1_4
                             88 	.globl _P1_3
                             89 	.globl _P1_2
                             90 	.globl _P1_1
                             91 	.globl _P1_0
                             92 	.globl _TF1
                             93 	.globl _TR1
                             94 	.globl _TF0
                             95 	.globl _TR0
                             96 	.globl _IE1
                             97 	.globl _IT1
                             98 	.globl _IE0
                             99 	.globl _IT0
                            100 	.globl _P0_7
                            101 	.globl _P0_6
                            102 	.globl _P0_5
                            103 	.globl _P0_4
                            104 	.globl _P0_3
                            105 	.globl _P0_2
                            106 	.globl _P0_1
                            107 	.globl _P0_0
                            108 	.globl _TH2
                            109 	.globl _TL2
                            110 	.globl _RCAP2H
                            111 	.globl _RCAP2L
                            112 	.globl _T2CON
                            113 	.globl _B
                            114 	.globl _ACC
                            115 	.globl _PSW
                            116 	.globl _IP
                            117 	.globl _P3
                            118 	.globl _IE
                            119 	.globl _P2
                            120 	.globl _SBUF
                            121 	.globl _SCON
                            122 	.globl _P1
                            123 	.globl _TH1
                            124 	.globl _TH0
                            125 	.globl _TL1
                            126 	.globl _TL0
                            127 	.globl _TMOD
                            128 	.globl _TCON
                            129 	.globl _PCON
                            130 	.globl _DPH
                            131 	.globl _DPL
                            132 	.globl _SP
                            133 	.globl _P0
                            134 	.globl _matrixData
                            135 	.globl _rowVal
                            136 	.globl _rowCounter
                            137 ;--------------------------------------------------------
                            138 ; special function registers
                            139 ;--------------------------------------------------------
                            140 	.area RSEG    (ABS,DATA)
   0000                     141 	.org 0x0000
                    0080    142 _P0	=	0x0080
                    0081    143 _SP	=	0x0081
                    0082    144 _DPL	=	0x0082
                    0083    145 _DPH	=	0x0083
                    0087    146 _PCON	=	0x0087
                    0088    147 _TCON	=	0x0088
                    0089    148 _TMOD	=	0x0089
                    008A    149 _TL0	=	0x008a
                    008B    150 _TL1	=	0x008b
                    008C    151 _TH0	=	0x008c
                    008D    152 _TH1	=	0x008d
                    0090    153 _P1	=	0x0090
                    0098    154 _SCON	=	0x0098
                    0099    155 _SBUF	=	0x0099
                    00A0    156 _P2	=	0x00a0
                    00A8    157 _IE	=	0x00a8
                    00B0    158 _P3	=	0x00b0
                    00B8    159 _IP	=	0x00b8
                    00D0    160 _PSW	=	0x00d0
                    00E0    161 _ACC	=	0x00e0
                    00F0    162 _B	=	0x00f0
                    00C8    163 _T2CON	=	0x00c8
                    00CA    164 _RCAP2L	=	0x00ca
                    00CB    165 _RCAP2H	=	0x00cb
                    00CC    166 _TL2	=	0x00cc
                    00CD    167 _TH2	=	0x00cd
                            168 ;--------------------------------------------------------
                            169 ; special function bits
                            170 ;--------------------------------------------------------
                            171 	.area RSEG    (ABS,DATA)
   0000                     172 	.org 0x0000
                    0080    173 _P0_0	=	0x0080
                    0081    174 _P0_1	=	0x0081
                    0082    175 _P0_2	=	0x0082
                    0083    176 _P0_3	=	0x0083
                    0084    177 _P0_4	=	0x0084
                    0085    178 _P0_5	=	0x0085
                    0086    179 _P0_6	=	0x0086
                    0087    180 _P0_7	=	0x0087
                    0088    181 _IT0	=	0x0088
                    0089    182 _IE0	=	0x0089
                    008A    183 _IT1	=	0x008a
                    008B    184 _IE1	=	0x008b
                    008C    185 _TR0	=	0x008c
                    008D    186 _TF0	=	0x008d
                    008E    187 _TR1	=	0x008e
                    008F    188 _TF1	=	0x008f
                    0090    189 _P1_0	=	0x0090
                    0091    190 _P1_1	=	0x0091
                    0092    191 _P1_2	=	0x0092
                    0093    192 _P1_3	=	0x0093
                    0094    193 _P1_4	=	0x0094
                    0095    194 _P1_5	=	0x0095
                    0096    195 _P1_6	=	0x0096
                    0097    196 _P1_7	=	0x0097
                    0098    197 _RI	=	0x0098
                    0099    198 _TI	=	0x0099
                    009A    199 _RB8	=	0x009a
                    009B    200 _TB8	=	0x009b
                    009C    201 _REN	=	0x009c
                    009D    202 _SM2	=	0x009d
                    009E    203 _SM1	=	0x009e
                    009F    204 _SM0	=	0x009f
                    00A0    205 _P2_0	=	0x00a0
                    00A1    206 _P2_1	=	0x00a1
                    00A2    207 _P2_2	=	0x00a2
                    00A3    208 _P2_3	=	0x00a3
                    00A4    209 _P2_4	=	0x00a4
                    00A5    210 _P2_5	=	0x00a5
                    00A6    211 _P2_6	=	0x00a6
                    00A7    212 _P2_7	=	0x00a7
                    00A8    213 _EX0	=	0x00a8
                    00A9    214 _ET0	=	0x00a9
                    00AA    215 _EX1	=	0x00aa
                    00AB    216 _ET1	=	0x00ab
                    00AC    217 _ES	=	0x00ac
                    00AF    218 _EA	=	0x00af
                    00B0    219 _P3_0	=	0x00b0
                    00B1    220 _P3_1	=	0x00b1
                    00B2    221 _P3_2	=	0x00b2
                    00B3    222 _P3_3	=	0x00b3
                    00B4    223 _P3_4	=	0x00b4
                    00B5    224 _P3_5	=	0x00b5
                    00B6    225 _P3_6	=	0x00b6
                    00B7    226 _P3_7	=	0x00b7
                    00B0    227 _RXD	=	0x00b0
                    00B1    228 _TXD	=	0x00b1
                    00B2    229 _INT0	=	0x00b2
                    00B3    230 _INT1	=	0x00b3
                    00B4    231 _T0	=	0x00b4
                    00B5    232 _T1	=	0x00b5
                    00B6    233 _WR	=	0x00b6
                    00B7    234 _RD	=	0x00b7
                    00B8    235 _PX0	=	0x00b8
                    00B9    236 _PT0	=	0x00b9
                    00BA    237 _PX1	=	0x00ba
                    00BB    238 _PT1	=	0x00bb
                    00BC    239 _PS	=	0x00bc
                    00D0    240 _P	=	0x00d0
                    00D1    241 _F1	=	0x00d1
                    00D2    242 _OV	=	0x00d2
                    00D3    243 _RS0	=	0x00d3
                    00D4    244 _RS1	=	0x00d4
                    00D5    245 _F0	=	0x00d5
                    00D6    246 _AC	=	0x00d6
                    00D7    247 _CY	=	0x00d7
                    00AD    248 _ET2	=	0x00ad
                    00BD    249 _PT2	=	0x00bd
                    00C8    250 _T2CON_0	=	0x00c8
                    00C9    251 _T2CON_1	=	0x00c9
                    00CA    252 _T2CON_2	=	0x00ca
                    00CB    253 _T2CON_3	=	0x00cb
                    00CC    254 _T2CON_4	=	0x00cc
                    00CD    255 _T2CON_5	=	0x00cd
                    00CE    256 _T2CON_6	=	0x00ce
                    00CF    257 _T2CON_7	=	0x00cf
                    00C8    258 _CP_RL2	=	0x00c8
                    00C9    259 _C_T2	=	0x00c9
                    00CA    260 _TR2	=	0x00ca
                    00CB    261 _EXEN2	=	0x00cb
                    00CC    262 _TCLK	=	0x00cc
                    00CD    263 _RCLK	=	0x00cd
                    00CE    264 _EXF2	=	0x00ce
                    00CF    265 _TF2	=	0x00cf
                            266 ;--------------------------------------------------------
                            267 ; overlayable register banks
                            268 ;--------------------------------------------------------
                            269 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     270 	.ds 8
                            271 	.area REG_BANK_1	(REL,OVR,DATA)
   0008                     272 	.ds 8
                            273 ;--------------------------------------------------------
                            274 ; overlayable bit register bank
                            275 ;--------------------------------------------------------
                            276 	.area BIT_BANK	(REL,OVR,DATA)
   0021                     277 bits:
   0021                     278 	.ds 1
                    8000    279 	b0 = bits[0]
                    8100    280 	b1 = bits[1]
                    8200    281 	b2 = bits[2]
                    8300    282 	b3 = bits[3]
                    8400    283 	b4 = bits[4]
                    8500    284 	b5 = bits[5]
                    8600    285 	b6 = bits[6]
                    8700    286 	b7 = bits[7]
                            287 ;--------------------------------------------------------
                            288 ; internal ram data
                            289 ;--------------------------------------------------------
                            290 	.area DSEG    (DATA)
   0010                     291 _rowCounter::
   0010                     292 	.ds 1
   0011                     293 _rowVal::
   0011                     294 	.ds 9
                            295 ;--------------------------------------------------------
                            296 ; overlayable items in internal ram 
                            297 ;--------------------------------------------------------
                            298 	.area	OSEG    (OVR,DATA)
                            299 ;--------------------------------------------------------
                            300 ; Stack segment in internal ram 
                            301 ;--------------------------------------------------------
                            302 	.area	SSEG	(DATA)
   0042                     303 __start__stack:
   0042                     304 	.ds	1
                            305 
                            306 ;--------------------------------------------------------
                            307 ; indirectly addressable internal ram data
                            308 ;--------------------------------------------------------
                            309 	.area ISEG    (DATA)
   0022                     310 _matrixData::
   0022                     311 	.ds 32
                            312 ;--------------------------------------------------------
                            313 ; absolute internal ram data
                            314 ;--------------------------------------------------------
                            315 	.area IABS    (ABS,DATA)
                            316 	.area IABS    (ABS,DATA)
                            317 ;--------------------------------------------------------
                            318 ; bit data
                            319 ;--------------------------------------------------------
                            320 	.area BSEG    (BIT)
   0000                     321 _shiftByte_sloc0_1_0:
   0000                     322 	.ds 1
                            323 ;--------------------------------------------------------
                            324 ; paged external ram data
                            325 ;--------------------------------------------------------
                            326 	.area PSEG    (PAG,XDATA)
                            327 ;--------------------------------------------------------
                            328 ; external ram data
                            329 ;--------------------------------------------------------
                            330 	.area XSEG    (XDATA)
                            331 ;--------------------------------------------------------
                            332 ; absolute external ram data
                            333 ;--------------------------------------------------------
                            334 	.area XABS    (ABS,XDATA)
                            335 ;--------------------------------------------------------
                            336 ; external initialized ram data
                            337 ;--------------------------------------------------------
                            338 	.area XISEG   (XDATA)
                            339 	.area HOME    (CODE)
                            340 	.area GSINIT0 (CODE)
                            341 	.area GSINIT1 (CODE)
                            342 	.area GSINIT2 (CODE)
                            343 	.area GSINIT3 (CODE)
                            344 	.area GSINIT4 (CODE)
                            345 	.area GSINIT5 (CODE)
                            346 	.area GSINIT  (CODE)
                            347 	.area GSFINAL (CODE)
                            348 	.area CSEG    (CODE)
                            349 ;--------------------------------------------------------
                            350 ; interrupt vector 
                            351 ;--------------------------------------------------------
                            352 	.area HOME    (CODE)
   0000                     353 __interrupt_vect:
   0000 02 00 13            354 	ljmp	__sdcc_gsinit_startup
   0003 32                  355 	reti
   0004                     356 	.ds	7
   000B 02 00 E6            357 	ljmp	_matrixIsr
                            358 ;--------------------------------------------------------
                            359 ; global & static initialisations
                            360 ;--------------------------------------------------------
                            361 	.area HOME    (CODE)
                            362 	.area GSINIT  (CODE)
                            363 	.area GSFINAL (CODE)
                            364 	.area GSINIT  (CODE)
                            365 	.globl __sdcc_gsinit_startup
                            366 	.globl __sdcc_program_startup
                            367 	.globl __start__stack
                            368 	.globl __mcs51_genXINIT
                            369 	.globl __mcs51_genXRAMCLEAR
                            370 	.globl __mcs51_genRAMCLEAR
                            371 ;	8052_megaMatrix.c:12: unsigned char rowCounter = 0;
   006C 75 10 00            372 	mov	_rowCounter,#0x00
                            373 ;	8052_megaMatrix.c:14: unsigned char rowVal[9] = {0b11111110,0b11111101,0b11111011,0b11110111,0b11101111,0b11011111,0b10111111,0b01111111,0b11111111};
   006F 75 11 FE            374 	mov	_rowVal,#0xFE
   0072 75 12 FD            375 	mov	(_rowVal + 0x0001),#0xFD
   0075 75 13 FB            376 	mov	(_rowVal + 0x0002),#0xFB
   0078 75 14 F7            377 	mov	(_rowVal + 0x0003),#0xF7
   007B 75 15 EF            378 	mov	(_rowVal + 0x0004),#0xEF
   007E 75 16 DF            379 	mov	(_rowVal + 0x0005),#0xDF
   0081 75 17 BF            380 	mov	(_rowVal + 0x0006),#0xBF
   0084 75 18 7F            381 	mov	(_rowVal + 0x0007),#0x7F
   0087 75 19 FF            382 	mov	(_rowVal + 0x0008),#0xFF
                            383 	.area GSFINAL (CODE)
   008A 02 00 0E            384 	ljmp	__sdcc_program_startup
                            385 ;--------------------------------------------------------
                            386 ; Home
                            387 ;--------------------------------------------------------
                            388 	.area HOME    (CODE)
                            389 	.area HOME    (CODE)
   000E                     390 __sdcc_program_startup:
   000E 12 01 95            391 	lcall	_main
                            392 ;	return from main will lock up
   0011 80 FE               393 	sjmp .
                            394 ;--------------------------------------------------------
                            395 ; code
                            396 ;--------------------------------------------------------
                            397 	.area CSEG    (CODE)
                            398 ;------------------------------------------------------------
                            399 ;Allocation info for local variables in function 'shiftByte'
                            400 ;------------------------------------------------------------
                            401 ;byte                      Allocated to registers r7 
                            402 ;------------------------------------------------------------
                            403 ;	8052_megaMatrix.c:24: void shiftByte(unsigned char byte){
                            404 ;	-----------------------------------------
                            405 ;	 function shiftByte
                            406 ;	-----------------------------------------
   008D                     407 _shiftByte:
                    0007    408 	ar7 = 0x07
                    0006    409 	ar6 = 0x06
                    0005    410 	ar5 = 0x05
                    0004    411 	ar4 = 0x04
                    0003    412 	ar3 = 0x03
                    0002    413 	ar2 = 0x02
                    0001    414 	ar1 = 0x01
                    0000    415 	ar0 = 0x00
                            416 ;	8052_megaMatrix.c:25: SHIFTREG_DATA = byte&0x01;
   008D E5 82               417 	mov	a,dpl
   008F FF                  418 	mov	r7,a
   0090 13                  419 	rrc	a
   0091 92 00               420 	mov  _shiftByte_sloc0_1_0,c
   0093 92 92               421 	mov	_P1_2,c
                            422 ;	8052_megaMatrix.c:26: SHIFTREG_CLOCK = 1;
   0095 D2 90               423 	setb	_P1_0
                            424 ;	8052_megaMatrix.c:27: SHIFTREG_CLOCK = 0;
   0097 C2 90               425 	clr	_P1_0
                            426 ;	8052_megaMatrix.c:28: SHIFTREG_DATA = byte&0x02;
   0099 EF                  427 	mov	a,r7
   009A A2 E1               428 	mov	c,acc[1]
   009C 92 00               429 	mov  _shiftByte_sloc0_1_0,c
   009E 92 92               430 	mov	_P1_2,c
                            431 ;	8052_megaMatrix.c:29: SHIFTREG_CLOCK = 1;
   00A0 D2 90               432 	setb	_P1_0
                            433 ;	8052_megaMatrix.c:30: SHIFTREG_CLOCK = 0;
   00A2 C2 90               434 	clr	_P1_0
                            435 ;	8052_megaMatrix.c:31: SHIFTREG_DATA = byte&0x04;
   00A4 EF                  436 	mov	a,r7
   00A5 A2 E2               437 	mov	c,acc[2]
   00A7 92 00               438 	mov  _shiftByte_sloc0_1_0,c
   00A9 92 92               439 	mov	_P1_2,c
                            440 ;	8052_megaMatrix.c:32: SHIFTREG_CLOCK = 1;
   00AB D2 90               441 	setb	_P1_0
                            442 ;	8052_megaMatrix.c:33: SHIFTREG_CLOCK = 0;
   00AD C2 90               443 	clr	_P1_0
                            444 ;	8052_megaMatrix.c:34: SHIFTREG_DATA = byte&0x08;
   00AF EF                  445 	mov	a,r7
   00B0 A2 E3               446 	mov	c,acc[3]
   00B2 92 00               447 	mov  _shiftByte_sloc0_1_0,c
   00B4 92 92               448 	mov	_P1_2,c
                            449 ;	8052_megaMatrix.c:35: SHIFTREG_CLOCK = 1;
   00B6 D2 90               450 	setb	_P1_0
                            451 ;	8052_megaMatrix.c:36: SHIFTREG_CLOCK = 0;
   00B8 C2 90               452 	clr	_P1_0
                            453 ;	8052_megaMatrix.c:37: SHIFTREG_DATA = byte&0x10;
   00BA EF                  454 	mov	a,r7
   00BB A2 E4               455 	mov	c,acc[4]
   00BD 92 00               456 	mov  _shiftByte_sloc0_1_0,c
   00BF 92 92               457 	mov	_P1_2,c
                            458 ;	8052_megaMatrix.c:38: SHIFTREG_CLOCK = 1;
   00C1 D2 90               459 	setb	_P1_0
                            460 ;	8052_megaMatrix.c:39: SHIFTREG_CLOCK = 0;
   00C3 C2 90               461 	clr	_P1_0
                            462 ;	8052_megaMatrix.c:40: SHIFTREG_DATA = byte&0x20;
   00C5 EF                  463 	mov	a,r7
   00C6 A2 E5               464 	mov	c,acc[5]
   00C8 92 00               465 	mov  _shiftByte_sloc0_1_0,c
   00CA 92 92               466 	mov	_P1_2,c
                            467 ;	8052_megaMatrix.c:41: SHIFTREG_CLOCK = 1;
   00CC D2 90               468 	setb	_P1_0
                            469 ;	8052_megaMatrix.c:42: SHIFTREG_CLOCK = 0;
   00CE C2 90               470 	clr	_P1_0
                            471 ;	8052_megaMatrix.c:43: SHIFTREG_DATA = byte&0x40;
   00D0 EF                  472 	mov	a,r7
   00D1 A2 E6               473 	mov	c,acc[6]
   00D3 92 00               474 	mov  _shiftByte_sloc0_1_0,c
   00D5 92 92               475 	mov	_P1_2,c
                            476 ;	8052_megaMatrix.c:44: SHIFTREG_CLOCK = 1;
   00D7 D2 90               477 	setb	_P1_0
                            478 ;	8052_megaMatrix.c:45: SHIFTREG_CLOCK = 0;
   00D9 C2 90               479 	clr	_P1_0
                            480 ;	8052_megaMatrix.c:46: SHIFTREG_DATA = byte&0x80;
   00DB EF                  481 	mov	a,r7
   00DC 33                  482 	rlc	a
   00DD 92 00               483 	mov  _shiftByte_sloc0_1_0,c
   00DF 92 92               484 	mov	_P1_2,c
                            485 ;	8052_megaMatrix.c:47: SHIFTREG_CLOCK = 1;
   00E1 D2 90               486 	setb	_P1_0
                            487 ;	8052_megaMatrix.c:48: SHIFTREG_CLOCK = 0;
   00E3 C2 90               488 	clr	_P1_0
   00E5 22                  489 	ret
                            490 ;------------------------------------------------------------
                            491 ;Allocation info for local variables in function 'matrixIsr'
                            492 ;------------------------------------------------------------
                            493 ;	8052_megaMatrix.c:52: void matrixIsr() __interrupt(TF0_VECTOR) __using(1){
                            494 ;	-----------------------------------------
                            495 ;	 function matrixIsr
                            496 ;	-----------------------------------------
   00E6                     497 _matrixIsr:
                    000F    498 	ar7 = 0x0F
                    000E    499 	ar6 = 0x0E
                    000D    500 	ar5 = 0x0D
                    000C    501 	ar4 = 0x0C
                    000B    502 	ar3 = 0x0B
                    000A    503 	ar2 = 0x0A
                    0009    504 	ar1 = 0x09
                    0008    505 	ar0 = 0x08
   00E6 C0 21               506 	push	bits
   00E8 C0 E0               507 	push	acc
   00EA C0 F0               508 	push	b
   00EC C0 82               509 	push	dpl
   00EE C0 83               510 	push	dph
   00F0 C0 07               511 	push	(0+7)
   00F2 C0 06               512 	push	(0+6)
   00F4 C0 05               513 	push	(0+5)
   00F6 C0 04               514 	push	(0+4)
   00F8 C0 03               515 	push	(0+3)
   00FA C0 02               516 	push	(0+2)
   00FC C0 01               517 	push	(0+1)
   00FE C0 00               518 	push	(0+0)
   0100 C0 D0               519 	push	psw
   0102 75 D0 08            520 	mov	psw,#0x08
                            521 ;	8052_megaMatrix.c:53: DEBUG_PIN = 1; //Mostrar que entramos a la interrupci�n
   0105 D2 97               522 	setb	_P1_7
                            523 ;	8052_megaMatrix.c:55: TH0 = (65535 - 2*US_PER_ROW) >> 8; //Reiniciar el timer0
   0107 75 8C F8            524 	mov	_TH0,#0xF8
                            525 ;	8052_megaMatrix.c:56: TL0 = (65535 - 2*US_PER_ROW) & 0xFF;
   010A 75 8A 2F            526 	mov	_TL0,#0x2F
                            527 ;	8052_megaMatrix.c:58: PORT_ROW = rowVal[8]; //Apagamos todas las filas
   010D 85 19 A0            528 	mov	_P2,(_rowVal + 0x0008)
                            529 ;	8052_megaMatrix.c:60: shiftByte(matrixData[rowCounter*4+3]); //Mandamos todos los bytes correspondientes a los shift registers
   0110 E5 10               530 	mov	a,_rowCounter
   0112 25 10               531 	add	a,_rowCounter
   0114 25 E0               532 	add	a,acc
   0116 24 03               533 	add	a,#0x03
   0118 24 22               534 	add	a,#_matrixData
   011A F9                  535 	mov	r1,a
   011B 87 82               536 	mov	dpl,@r1
   011D 75 D0 00            537 	mov	psw,#0x00
   0120 12 00 8D            538 	lcall	_shiftByte
   0123 75 D0 08            539 	mov	psw,#0x08
                            540 ;	8052_megaMatrix.c:61: shiftByte(matrixData[rowCounter*4+2]);
   0126 E5 10               541 	mov	a,_rowCounter
   0128 25 10               542 	add	a,_rowCounter
   012A 25 E0               543 	add	a,acc
   012C 24 02               544 	add	a,#0x02
   012E 24 22               545 	add	a,#_matrixData
   0130 F9                  546 	mov	r1,a
   0131 87 82               547 	mov	dpl,@r1
   0133 75 D0 00            548 	mov	psw,#0x00
   0136 12 00 8D            549 	lcall	_shiftByte
   0139 75 D0 08            550 	mov	psw,#0x08
                            551 ;	8052_megaMatrix.c:62: shiftByte(matrixData[rowCounter*4+1]);
   013C E5 10               552 	mov	a,_rowCounter
   013E 25 10               553 	add	a,_rowCounter
   0140 25 E0               554 	add	a,acc
   0142 04                  555 	inc	a
   0143 24 22               556 	add	a,#_matrixData
   0145 F9                  557 	mov	r1,a
   0146 87 82               558 	mov	dpl,@r1
   0148 75 D0 00            559 	mov	psw,#0x00
   014B 12 00 8D            560 	lcall	_shiftByte
   014E 75 D0 08            561 	mov	psw,#0x08
                            562 ;	8052_megaMatrix.c:63: shiftByte(matrixData[rowCounter*4+0]);
   0151 E5 10               563 	mov	a,_rowCounter
   0153 25 10               564 	add	a,_rowCounter
   0155 25 E0               565 	add	a,acc
   0157 24 22               566 	add	a,#_matrixData
   0159 F9                  567 	mov	r1,a
   015A 87 82               568 	mov	dpl,@r1
   015C 75 D0 00            569 	mov	psw,#0x00
   015F 12 00 8D            570 	lcall	_shiftByte
   0162 75 D0 08            571 	mov	psw,#0x08
                            572 ;	8052_megaMatrix.c:65: SHIFTREG_LATCH = 1; //"Actualizamos" la etapa de salida de los shift registers
   0165 D2 91               573 	setb	_P1_1
                            574 ;	8052_megaMatrix.c:66: SHIFTREG_LATCH = 0;
   0167 C2 91               575 	clr	_P1_1
                            576 ;	8052_megaMatrix.c:68: PORT_ROW = rowVal[rowCounter++]; //Activamos la fila correspondiente, pasamos a la pr�xima
   0169 AF 10               577 	mov	r7,_rowCounter
   016B 05 10               578 	inc	_rowCounter
   016D EF                  579 	mov	a,r7
   016E 24 11               580 	add	a,#_rowVal
   0170 F9                  581 	mov	r1,a
   0171 87 A0               582 	mov	_P2,@r1
                            583 ;	8052_megaMatrix.c:69: rowCounter&=7; //Solamente hay 8 filas, evitamos que se pase de 8
   0173 53 10 07            584 	anl	_rowCounter,#0x07
                            585 ;	8052_megaMatrix.c:71: DEBUG_PIN = 0;
   0176 C2 97               586 	clr	_P1_7
   0178 D0 D0               587 	pop	psw
   017A D0 00               588 	pop	(0+0)
   017C D0 01               589 	pop	(0+1)
   017E D0 02               590 	pop	(0+2)
   0180 D0 03               591 	pop	(0+3)
   0182 D0 04               592 	pop	(0+4)
   0184 D0 05               593 	pop	(0+5)
   0186 D0 06               594 	pop	(0+6)
   0188 D0 07               595 	pop	(0+7)
   018A D0 83               596 	pop	dph
   018C D0 82               597 	pop	dpl
   018E D0 F0               598 	pop	b
   0190 D0 E0               599 	pop	acc
   0192 D0 21               600 	pop	bits
   0194 32                  601 	reti
                            602 ;------------------------------------------------------------
                            603 ;Allocation info for local variables in function 'main'
                            604 ;------------------------------------------------------------
                            605 ;	8052_megaMatrix.c:74: void main(){
                            606 ;	-----------------------------------------
                            607 ;	 function main
                            608 ;	-----------------------------------------
   0195                     609 _main:
                    0007    610 	ar7 = 0x07
                    0006    611 	ar6 = 0x06
                    0005    612 	ar5 = 0x05
                    0004    613 	ar4 = 0x04
                    0003    614 	ar3 = 0x03
                    0002    615 	ar2 = 0x02
                    0001    616 	ar1 = 0x01
                    0000    617 	ar0 = 0x00
                            618 ;	8052_megaMatrix.c:76: TMOD = T0_M0;
   0195 75 89 01            619 	mov	_TMOD,#0x01
                            620 ;	8052_megaMatrix.c:77: TR0 = 1;
   0198 D2 8C               621 	setb	_TR0
                            622 ;	8052_megaMatrix.c:80: IE = 0x80;
   019A 75 A8 80            623 	mov	_IE,#0x80
                            624 ;	8052_megaMatrix.c:81: ET0 = 1;
   019D D2 A9               625 	setb	_ET0
                            626 ;	8052_megaMatrix.c:85: matrixData[0 ] = 0b10000001;
   019F 78 22               627 	mov	r0,#_matrixData
   01A1 76 81               628 	mov	@r0,#0x81
                            629 ;	8052_megaMatrix.c:86: matrixData[4 ] = 0b10000001;
   01A3 78 26               630 	mov	r0,#(_matrixData + 0x0004)
   01A5 76 81               631 	mov	@r0,#0x81
                            632 ;	8052_megaMatrix.c:87: matrixData[8 ] = 0b10000001;
   01A7 78 2A               633 	mov	r0,#(_matrixData + 0x0008)
   01A9 76 81               634 	mov	@r0,#0x81
                            635 ;	8052_megaMatrix.c:88: matrixData[12] = 0b11111111;
   01AB 78 2E               636 	mov	r0,#(_matrixData + 0x000c)
   01AD 76 FF               637 	mov	@r0,#0xFF
                            638 ;	8052_megaMatrix.c:89: matrixData[16] = 0b10000001;
   01AF 78 32               639 	mov	r0,#(_matrixData + 0x0010)
   01B1 76 81               640 	mov	@r0,#0x81
                            641 ;	8052_megaMatrix.c:90: matrixData[20] = 0b10000001;
   01B3 78 36               642 	mov	r0,#(_matrixData + 0x0014)
   01B5 76 81               643 	mov	@r0,#0x81
                            644 ;	8052_megaMatrix.c:91: matrixData[24] = 0b10000001;
   01B7 78 3A               645 	mov	r0,#(_matrixData + 0x0018)
   01B9 76 81               646 	mov	@r0,#0x81
                            647 ;	8052_megaMatrix.c:92: matrixData[28] = 0b10000001;
   01BB 78 3E               648 	mov	r0,#(_matrixData + 0x001c)
   01BD 76 81               649 	mov	@r0,#0x81
                            650 ;	8052_megaMatrix.c:95: matrixData[ 1] = 0b01111110;
   01BF 78 23               651 	mov	r0,#(_matrixData + 0x0001)
   01C1 76 7E               652 	mov	@r0,#0x7E
                            653 ;	8052_megaMatrix.c:96: matrixData[ 5] = 0b10000001;
   01C3 78 27               654 	mov	r0,#(_matrixData + 0x0005)
   01C5 76 81               655 	mov	@r0,#0x81
                            656 ;	8052_megaMatrix.c:97: matrixData[ 9] = 0b10000001;
   01C7 78 2B               657 	mov	r0,#(_matrixData + 0x0009)
   01C9 76 81               658 	mov	@r0,#0x81
                            659 ;	8052_megaMatrix.c:98: matrixData[13] = 0b10000001;
   01CB 78 2F               660 	mov	r0,#(_matrixData + 0x000d)
   01CD 76 81               661 	mov	@r0,#0x81
                            662 ;	8052_megaMatrix.c:99: matrixData[17] = 0b10000001;
   01CF 78 33               663 	mov	r0,#(_matrixData + 0x0011)
   01D1 76 81               664 	mov	@r0,#0x81
                            665 ;	8052_megaMatrix.c:100: matrixData[21] = 0b10000001;
   01D3 78 37               666 	mov	r0,#(_matrixData + 0x0015)
   01D5 76 81               667 	mov	@r0,#0x81
                            668 ;	8052_megaMatrix.c:101: matrixData[25] = 0b10000001;
   01D7 78 3B               669 	mov	r0,#(_matrixData + 0x0019)
   01D9 76 81               670 	mov	@r0,#0x81
                            671 ;	8052_megaMatrix.c:102: matrixData[29] = 0b01111110;
   01DB 78 3F               672 	mov	r0,#(_matrixData + 0x001d)
   01DD 76 7E               673 	mov	@r0,#0x7E
                            674 ;	8052_megaMatrix.c:105: matrixData[2 ] = 0b10000000;
   01DF 78 24               675 	mov	r0,#(_matrixData + 0x0002)
   01E1 76 80               676 	mov	@r0,#0x80
                            677 ;	8052_megaMatrix.c:106: matrixData[6 ] = 0b10000000;
   01E3 78 28               678 	mov	r0,#(_matrixData + 0x0006)
   01E5 76 80               679 	mov	@r0,#0x80
                            680 ;	8052_megaMatrix.c:107: matrixData[10] = 0b10000000;
   01E7 78 2C               681 	mov	r0,#(_matrixData + 0x000a)
   01E9 76 80               682 	mov	@r0,#0x80
                            683 ;	8052_megaMatrix.c:108: matrixData[14] = 0b10000000;
   01EB 78 30               684 	mov	r0,#(_matrixData + 0x000e)
   01ED 76 80               685 	mov	@r0,#0x80
                            686 ;	8052_megaMatrix.c:109: matrixData[18] = 0b10000000;
   01EF 78 34               687 	mov	r0,#(_matrixData + 0x0012)
   01F1 76 80               688 	mov	@r0,#0x80
                            689 ;	8052_megaMatrix.c:110: matrixData[22] = 0b10000000;
   01F3 78 38               690 	mov	r0,#(_matrixData + 0x0016)
   01F5 76 80               691 	mov	@r0,#0x80
                            692 ;	8052_megaMatrix.c:111: matrixData[26] = 0b10000000;
   01F7 78 3C               693 	mov	r0,#(_matrixData + 0x001a)
   01F9 76 80               694 	mov	@r0,#0x80
                            695 ;	8052_megaMatrix.c:112: matrixData[30] = 0b01111111;
   01FB 78 40               696 	mov	r0,#(_matrixData + 0x001e)
   01FD 76 7F               697 	mov	@r0,#0x7F
                            698 ;	8052_megaMatrix.c:115: matrixData[3 ] = 0b00011000;
   01FF 78 25               699 	mov	r0,#(_matrixData + 0x0003)
   0201 76 18               700 	mov	@r0,#0x18
                            701 ;	8052_megaMatrix.c:116: matrixData[7 ] = 0b00100100;
   0203 78 29               702 	mov	r0,#(_matrixData + 0x0007)
   0205 76 24               703 	mov	@r0,#0x24
                            704 ;	8052_megaMatrix.c:117: matrixData[11] = 0b01000010;
   0207 78 2D               705 	mov	r0,#(_matrixData + 0x000b)
   0209 76 42               706 	mov	@r0,#0x42
                            707 ;	8052_megaMatrix.c:118: matrixData[15] = 0b01000010;
   020B 78 31               708 	mov	r0,#(_matrixData + 0x000f)
   020D 76 42               709 	mov	@r0,#0x42
                            710 ;	8052_megaMatrix.c:119: matrixData[19] = 0b01111110;
   020F 78 35               711 	mov	r0,#(_matrixData + 0x0013)
   0211 76 7E               712 	mov	@r0,#0x7E
                            713 ;	8052_megaMatrix.c:120: matrixData[23] = 0b01000010;
   0213 78 39               714 	mov	r0,#(_matrixData + 0x0017)
   0215 76 42               715 	mov	@r0,#0x42
                            716 ;	8052_megaMatrix.c:121: matrixData[27] = 0b01000010;
   0217 78 3D               717 	mov	r0,#(_matrixData + 0x001b)
   0219 76 42               718 	mov	@r0,#0x42
                            719 ;	8052_megaMatrix.c:122: matrixData[31] = 0b01000010;
   021B 78 41               720 	mov	r0,#(_matrixData + 0x001f)
   021D 76 42               721 	mov	@r0,#0x42
                            722 ;	8052_megaMatrix.c:124: while(1);
   021F                     723 00102$:
   021F 80 FE               724 	sjmp	00102$
                            725 	.area CSEG    (CODE)
                            726 	.area CONST   (CODE)
                            727 	.area XINIT   (CODE)
                            728 	.area CABS    (ABS,CODE)
