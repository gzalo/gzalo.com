                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : free open source ANSI-C Compiler
                              3 ; Version 3.2.0 #8008 (Jul  6 2012) (MINGW32)
                              4 ; This file was generated Thu Jan 24 02:07:53 2013
                              5 ;--------------------------------------------------------
                              6 	.module proyecto
                              7 	.optsdcc -mmcs51 --model-small
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _matrixColPut_PARM_3
                             13 	.globl _matrixColPut_PARM_2
                             14 	.globl _matrixGet_PARM_2
                             15 	.globl _matrixTgl_PARM_2
                             16 	.globl _matrixClr_PARM_2
                             17 	.globl _matrixSet_PARM_2
                             18 	.globl _song1Timing
                             19 	.globl _song1Notes
                             20 	.globl _fuente
                             21 	.globl _timing
                             22 	.globl _song
                             23 	.globl _soundNotes
                             24 	.globl _matrixTranslationY
                             25 	.globl _main
                             26 	.globl _gameLogic
                             27 	.globl _gameGuitar
                             28 	.globl _gameSnake
                             29 	.globl _gameChopper
                             30 	.globl _gameCar
                             31 	.globl _gameTetris
                             32 	.globl _gameList
                             33 	.globl _gameOver
                             34 	.globl _getRandomNumber
                             35 	.globl _upIsr
                             36 	.globl _leftIsr
                             37 	.globl _soundPlay
                             38 	.globl _soundStop
                             39 	.globl _soundIsr
                             40 	.globl _matrixColPut
                             41 	.globl _matrixGet
                             42 	.globl _matrixTgl
                             43 	.globl _matrixClr
                             44 	.globl _matrixSet
                             45 	.globl _matrixTgls
                             46 	.globl _matrixSets
                             47 	.globl _matrixSetsI
                             48 	.globl _matrixClsI
                             49 	.globl _matrixCls
                             50 	.globl _matrixIsr
                             51 	.globl _CY
                             52 	.globl _AC
                             53 	.globl _F0
                             54 	.globl _RS1
                             55 	.globl _RS0
                             56 	.globl _OV
                             57 	.globl _FL
                             58 	.globl _P
                             59 	.globl _TF2
                             60 	.globl _EXF2
                             61 	.globl _RCLK
                             62 	.globl _TCLK
                             63 	.globl _EXEN2
                             64 	.globl _TR2
                             65 	.globl _C_T2
                             66 	.globl _CP_RL2
                             67 	.globl _T2CON_7
                             68 	.globl _T2CON_6
                             69 	.globl _T2CON_5
                             70 	.globl _T2CON_4
                             71 	.globl _T2CON_3
                             72 	.globl _T2CON_2
                             73 	.globl _T2CON_1
                             74 	.globl _T2CON_0
                             75 	.globl _PT2
                             76 	.globl _PS
                             77 	.globl _PT1
                             78 	.globl _PX1
                             79 	.globl _PT0
                             80 	.globl _PX0
                             81 	.globl _RD
                             82 	.globl _WR
                             83 	.globl _T1
                             84 	.globl _T0
                             85 	.globl _INT1
                             86 	.globl _INT0
                             87 	.globl _TXD
                             88 	.globl _RXD
                             89 	.globl _P3_7
                             90 	.globl _P3_6
                             91 	.globl _P3_5
                             92 	.globl _P3_4
                             93 	.globl _P3_3
                             94 	.globl _P3_2
                             95 	.globl _P3_1
                             96 	.globl _P3_0
                             97 	.globl _EA
                             98 	.globl _ET2
                             99 	.globl _ES
                            100 	.globl _ET1
                            101 	.globl _EX1
                            102 	.globl _ET0
                            103 	.globl _EX0
                            104 	.globl _P2_7
                            105 	.globl _P2_6
                            106 	.globl _P2_5
                            107 	.globl _P2_4
                            108 	.globl _P2_3
                            109 	.globl _P2_2
                            110 	.globl _P2_1
                            111 	.globl _P2_0
                            112 	.globl _SM0
                            113 	.globl _SM1
                            114 	.globl _SM2
                            115 	.globl _REN
                            116 	.globl _TB8
                            117 	.globl _RB8
                            118 	.globl _TI
                            119 	.globl _RI
                            120 	.globl _T2EX
                            121 	.globl _T2
                            122 	.globl _P1_7
                            123 	.globl _P1_6
                            124 	.globl _P1_5
                            125 	.globl _P1_4
                            126 	.globl _P1_3
                            127 	.globl _P1_2
                            128 	.globl _P1_1
                            129 	.globl _P1_0
                            130 	.globl _TF1
                            131 	.globl _TR1
                            132 	.globl _TF0
                            133 	.globl _TR0
                            134 	.globl _IE1
                            135 	.globl _IT1
                            136 	.globl _IE0
                            137 	.globl _IT0
                            138 	.globl _P0_7
                            139 	.globl _P0_6
                            140 	.globl _P0_5
                            141 	.globl _P0_4
                            142 	.globl _P0_3
                            143 	.globl _P0_2
                            144 	.globl _P0_1
                            145 	.globl _P0_0
                            146 	.globl _B
                            147 	.globl _A
                            148 	.globl _ACC
                            149 	.globl _PSW
                            150 	.globl _TH2
                            151 	.globl _TL2
                            152 	.globl _RCAP2H
                            153 	.globl _RCAP2L
                            154 	.globl _T2MOD
                            155 	.globl _T2CON
                            156 	.globl _IP
                            157 	.globl _P3
                            158 	.globl _IE
                            159 	.globl _P2
                            160 	.globl _SBUF
                            161 	.globl _SCON
                            162 	.globl _P1
                            163 	.globl _TH1
                            164 	.globl _TH0
                            165 	.globl _TL1
                            166 	.globl _TL0
                            167 	.globl _TMOD
                            168 	.globl _TCON
                            169 	.globl _PCON
                            170 	.globl _DPH
                            171 	.globl _DPL
                            172 	.globl _SP
                            173 	.globl _P0
                            174 	.globl _snakePosY
                            175 	.globl _snakePosX
                            176 	.globl _currentTiming
                            177 	.globl _currentNote
                            178 	.globl _buttonRight
                            179 	.globl _buttonLeft
                            180 	.globl _buttonDown
                            181 	.globl _buttonUp
                            182 	.globl _score
                            183 	.globl _loop
                            184 	.globl _vY
                            185 	.globl _vX
                            186 	.globl _keyAffects
                            187 	.globl _snakeLen
                            188 	.globl _fruitY
                            189 	.globl _fruitX
                            190 	.globl _randomNumber
                            191 	.globl _state
                            192 	.globl _game
                            193 	.globl _posY
                            194 	.globl _posX
                            195 	.globl _matrixLoop
                            196 	.globl _matrixIntensity
                            197 	.globl _matrixData
                            198 	.globl _matrixPtr
                            199 ;--------------------------------------------------------
                            200 ; special function registers
                            201 ;--------------------------------------------------------
                            202 	.area RSEG    (ABS,DATA)
   0000                     203 	.org 0x0000
                    0080    204 _P0	=	0x0080
                    0081    205 _SP	=	0x0081
                    0082    206 _DPL	=	0x0082
                    0083    207 _DPH	=	0x0083
                    0087    208 _PCON	=	0x0087
                    0088    209 _TCON	=	0x0088
                    0089    210 _TMOD	=	0x0089
                    008A    211 _TL0	=	0x008a
                    008B    212 _TL1	=	0x008b
                    008C    213 _TH0	=	0x008c
                    008D    214 _TH1	=	0x008d
                    0090    215 _P1	=	0x0090
                    0098    216 _SCON	=	0x0098
                    0099    217 _SBUF	=	0x0099
                    00A0    218 _P2	=	0x00a0
                    00A8    219 _IE	=	0x00a8
                    00B0    220 _P3	=	0x00b0
                    00B8    221 _IP	=	0x00b8
                    00C8    222 _T2CON	=	0x00c8
                    00C9    223 _T2MOD	=	0x00c9
                    00CA    224 _RCAP2L	=	0x00ca
                    00CB    225 _RCAP2H	=	0x00cb
                    00CC    226 _TL2	=	0x00cc
                    00CD    227 _TH2	=	0x00cd
                    00D0    228 _PSW	=	0x00d0
                    00E0    229 _ACC	=	0x00e0
                    00E0    230 _A	=	0x00e0
                    00F0    231 _B	=	0x00f0
                            232 ;--------------------------------------------------------
                            233 ; special function bits
                            234 ;--------------------------------------------------------
                            235 	.area RSEG    (ABS,DATA)
   0000                     236 	.org 0x0000
                    0080    237 _P0_0	=	0x0080
                    0081    238 _P0_1	=	0x0081
                    0082    239 _P0_2	=	0x0082
                    0083    240 _P0_3	=	0x0083
                    0084    241 _P0_4	=	0x0084
                    0085    242 _P0_5	=	0x0085
                    0086    243 _P0_6	=	0x0086
                    0087    244 _P0_7	=	0x0087
                    0088    245 _IT0	=	0x0088
                    0089    246 _IE0	=	0x0089
                    008A    247 _IT1	=	0x008a
                    008B    248 _IE1	=	0x008b
                    008C    249 _TR0	=	0x008c
                    008D    250 _TF0	=	0x008d
                    008E    251 _TR1	=	0x008e
                    008F    252 _TF1	=	0x008f
                    0090    253 _P1_0	=	0x0090
                    0091    254 _P1_1	=	0x0091
                    0092    255 _P1_2	=	0x0092
                    0093    256 _P1_3	=	0x0093
                    0094    257 _P1_4	=	0x0094
                    0095    258 _P1_5	=	0x0095
                    0096    259 _P1_6	=	0x0096
                    0097    260 _P1_7	=	0x0097
                    0090    261 _T2	=	0x0090
                    0091    262 _T2EX	=	0x0091
                    0098    263 _RI	=	0x0098
                    0099    264 _TI	=	0x0099
                    009A    265 _RB8	=	0x009a
                    009B    266 _TB8	=	0x009b
                    009C    267 _REN	=	0x009c
                    009D    268 _SM2	=	0x009d
                    009E    269 _SM1	=	0x009e
                    009F    270 _SM0	=	0x009f
                    00A0    271 _P2_0	=	0x00a0
                    00A1    272 _P2_1	=	0x00a1
                    00A2    273 _P2_2	=	0x00a2
                    00A3    274 _P2_3	=	0x00a3
                    00A4    275 _P2_4	=	0x00a4
                    00A5    276 _P2_5	=	0x00a5
                    00A6    277 _P2_6	=	0x00a6
                    00A7    278 _P2_7	=	0x00a7
                    00A8    279 _EX0	=	0x00a8
                    00A9    280 _ET0	=	0x00a9
                    00AA    281 _EX1	=	0x00aa
                    00AB    282 _ET1	=	0x00ab
                    00AC    283 _ES	=	0x00ac
                    00AD    284 _ET2	=	0x00ad
                    00AF    285 _EA	=	0x00af
                    00B0    286 _P3_0	=	0x00b0
                    00B1    287 _P3_1	=	0x00b1
                    00B2    288 _P3_2	=	0x00b2
                    00B3    289 _P3_3	=	0x00b3
                    00B4    290 _P3_4	=	0x00b4
                    00B5    291 _P3_5	=	0x00b5
                    00B6    292 _P3_6	=	0x00b6
                    00B7    293 _P3_7	=	0x00b7
                    00B0    294 _RXD	=	0x00b0
                    00B1    295 _TXD	=	0x00b1
                    00B2    296 _INT0	=	0x00b2
                    00B3    297 _INT1	=	0x00b3
                    00B4    298 _T0	=	0x00b4
                    00B5    299 _T1	=	0x00b5
                    00B6    300 _WR	=	0x00b6
                    00B7    301 _RD	=	0x00b7
                    00B8    302 _PX0	=	0x00b8
                    00B9    303 _PT0	=	0x00b9
                    00BA    304 _PX1	=	0x00ba
                    00BB    305 _PT1	=	0x00bb
                    00BC    306 _PS	=	0x00bc
                    00BD    307 _PT2	=	0x00bd
                    00C8    308 _T2CON_0	=	0x00c8
                    00C9    309 _T2CON_1	=	0x00c9
                    00CA    310 _T2CON_2	=	0x00ca
                    00CB    311 _T2CON_3	=	0x00cb
                    00CC    312 _T2CON_4	=	0x00cc
                    00CD    313 _T2CON_5	=	0x00cd
                    00CE    314 _T2CON_6	=	0x00ce
                    00CF    315 _T2CON_7	=	0x00cf
                    00C8    316 _CP_RL2	=	0x00c8
                    00C9    317 _C_T2	=	0x00c9
                    00CA    318 _TR2	=	0x00ca
                    00CB    319 _EXEN2	=	0x00cb
                    00CC    320 _TCLK	=	0x00cc
                    00CD    321 _RCLK	=	0x00cd
                    00CE    322 _EXF2	=	0x00ce
                    00CF    323 _TF2	=	0x00cf
                    00D0    324 _P	=	0x00d0
                    00D1    325 _FL	=	0x00d1
                    00D2    326 _OV	=	0x00d2
                    00D3    327 _RS0	=	0x00d3
                    00D4    328 _RS1	=	0x00d4
                    00D5    329 _F0	=	0x00d5
                    00D6    330 _AC	=	0x00d6
                    00D7    331 _CY	=	0x00d7
                            332 ;--------------------------------------------------------
                            333 ; overlayable register banks
                            334 ;--------------------------------------------------------
                            335 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     336 	.ds 8
                            337 ;--------------------------------------------------------
                            338 ; overlayable bit register bank
                            339 ;--------------------------------------------------------
                            340 	.area BIT_BANK	(REL,OVR,DATA)
   0021                     341 bits:
   0021                     342 	.ds 1
                    8000    343 	b0 = bits[0]
                    8100    344 	b1 = bits[1]
                    8200    345 	b2 = bits[2]
                    8300    346 	b3 = bits[3]
                    8400    347 	b4 = bits[4]
                    8500    348 	b5 = bits[5]
                    8600    349 	b6 = bits[6]
                    8700    350 	b7 = bits[7]
                            351 ;--------------------------------------------------------
                            352 ; internal ram data
                            353 ;--------------------------------------------------------
                            354 	.area DSEG    (DATA)
   0022                     355 _matrixPtr::
   0022                     356 	.ds 1
   0023                     357 _matrixData::
   0023                     358 	.ds 8
   002B                     359 _matrixIntensity::
   002B                     360 	.ds 8
   0033                     361 _matrixLoop::
   0033                     362 	.ds 1
   0034                     363 _posX::
   0034                     364 	.ds 1
   0035                     365 _posY::
   0035                     366 	.ds 1
   0036                     367 _game::
   0036                     368 	.ds 1
   0037                     369 _state::
   0037                     370 	.ds 1
   0038                     371 _randomNumber::
   0038                     372 	.ds 1
   0039                     373 _fruitX::
   0039                     374 	.ds 1
   003A                     375 _fruitY::
   003A                     376 	.ds 1
   003B                     377 _snakeLen::
   003B                     378 	.ds 1
   003C                     379 _keyAffects::
   003C                     380 	.ds 1
   003D                     381 _vX::
   003D                     382 	.ds 1
   003E                     383 _vY::
   003E                     384 	.ds 1
   003F                     385 _loop::
   003F                     386 	.ds 2
   0041                     387 _score::
   0041                     388 	.ds 1
   0042                     389 _buttonUp::
   0042                     390 	.ds 1
   0043                     391 _buttonDown::
   0043                     392 	.ds 1
   0044                     393 _buttonLeft::
   0044                     394 	.ds 1
   0045                     395 _buttonRight::
   0045                     396 	.ds 1
   0046                     397 _currentNote::
   0046                     398 	.ds 1
   0047                     399 _currentTiming::
   0047                     400 	.ds 1
   0048                     401 _gameOver_sloc0_1_0:
   0048                     402 	.ds 1
                            403 ;--------------------------------------------------------
                            404 ; overlayable items in internal ram 
                            405 ;--------------------------------------------------------
                            406 	.area	OSEG    (OVR,DATA)
   0008                     407 _matrixSet_PARM_2:
   0008                     408 	.ds 1
                            409 	.area	OSEG    (OVR,DATA)
   0008                     410 _matrixClr_PARM_2:
   0008                     411 	.ds 1
                            412 	.area	OSEG    (OVR,DATA)
   0008                     413 _matrixTgl_PARM_2:
   0008                     414 	.ds 1
                            415 	.area	OSEG    (OVR,DATA)
   0008                     416 _matrixGet_PARM_2:
   0008                     417 	.ds 1
                            418 	.area	OSEG    (OVR,DATA)
   0008                     419 _matrixColPut_PARM_2:
   0008                     420 	.ds 2
   000A                     421 _matrixColPut_PARM_3:
   000A                     422 	.ds 2
   000C                     423 _matrixColPut_retv_1_16:
   000C                     424 	.ds 1
                            425 	.area	OSEG    (OVR,DATA)
                            426 ;--------------------------------------------------------
                            427 ; Stack segment in internal ram 
                            428 ;--------------------------------------------------------
                            429 	.area	SSEG	(DATA)
   0049                     430 __start__stack:
   0049                     431 	.ds	1
                            432 
                            433 ;--------------------------------------------------------
                            434 ; indirectly addressable internal ram data
                            435 ;--------------------------------------------------------
                            436 	.area ISEG    (DATA)
                    0080    437 _snakePosX	=	0x0080
                    00C0    438 _snakePosY	=	0x00c0
                            439 ;--------------------------------------------------------
                            440 ; absolute internal ram data
                            441 ;--------------------------------------------------------
                            442 	.area IABS    (ABS,DATA)
                            443 	.area IABS    (ABS,DATA)
                            444 ;--------------------------------------------------------
                            445 ; bit data
                            446 ;--------------------------------------------------------
                            447 	.area BSEG    (BIT)
   0000                     448 _soundIsr_sloc0_1_0:
   0000                     449 	.ds 1
                            450 ;--------------------------------------------------------
                            451 ; paged external ram data
                            452 ;--------------------------------------------------------
                            453 	.area PSEG    (PAG,XDATA)
                            454 ;--------------------------------------------------------
                            455 ; external ram data
                            456 ;--------------------------------------------------------
                            457 	.area XSEG    (XDATA)
                            458 ;--------------------------------------------------------
                            459 ; absolute external ram data
                            460 ;--------------------------------------------------------
                            461 	.area XABS    (ABS,XDATA)
                            462 ;--------------------------------------------------------
                            463 ; external initialized ram data
                            464 ;--------------------------------------------------------
                            465 	.area XISEG   (XDATA)
                            466 	.area HOME    (CODE)
                            467 	.area GSINIT0 (CODE)
                            468 	.area GSINIT1 (CODE)
                            469 	.area GSINIT2 (CODE)
                            470 	.area GSINIT3 (CODE)
                            471 	.area GSINIT4 (CODE)
                            472 	.area GSINIT5 (CODE)
                            473 	.area GSINIT  (CODE)
                            474 	.area GSFINAL (CODE)
                            475 	.area CSEG    (CODE)
                            476 ;--------------------------------------------------------
                            477 ; interrupt vector 
                            478 ;--------------------------------------------------------
                            479 	.area HOME    (CODE)
   0000                     480 __interrupt_vect:
   0000 02 00 33            481 	ljmp	__sdcc_gsinit_startup
   0003 02 02 BE            482 	ljmp	_leftIsr
   0006                     483 	.ds	5
   000B 02 00 D9            484 	ljmp	_matrixIsr
   000E                     485 	.ds	5
   0013 02 02 C2            486 	ljmp	_upIsr
   0016                     487 	.ds	5
   001B 02 0A 20            488 	ljmp	_gameLogic
   001E                     489 	.ds	5
   0023 32                  490 	reti
   0024                     491 	.ds	7
   002B 02 02 97            492 	ljmp	_soundIsr
                            493 ;--------------------------------------------------------
                            494 ; global & static initialisations
                            495 ;--------------------------------------------------------
                            496 	.area HOME    (CODE)
                            497 	.area GSINIT  (CODE)
                            498 	.area GSFINAL (CODE)
                            499 	.area GSINIT  (CODE)
                            500 	.globl __sdcc_gsinit_startup
                            501 	.globl __sdcc_program_startup
                            502 	.globl __start__stack
                            503 	.globl __mcs51_genXINIT
                            504 	.globl __mcs51_genXRAMCLEAR
                            505 	.globl __mcs51_genRAMCLEAR
                            506 ;	ledmatrix.c:19: unsigned char matrixPtr = 0;
   008C 75 22 00            507 	mov	_matrixPtr,#0x00
                            508 ;	ledmatrix.c:24: unsigned char matrixIntensity[8] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
   008F 75 2B FF            509 	mov	_matrixIntensity,#0xFF
   0092 75 2C FF            510 	mov	(_matrixIntensity + 0x0001),#0xFF
   0095 75 2D FF            511 	mov	(_matrixIntensity + 0x0002),#0xFF
   0098 75 2E FF            512 	mov	(_matrixIntensity + 0x0003),#0xFF
   009B 75 2F FF            513 	mov	(_matrixIntensity + 0x0004),#0xFF
   009E 75 30 FF            514 	mov	(_matrixIntensity + 0x0005),#0xFF
   00A1 75 31 FF            515 	mov	(_matrixIntensity + 0x0006),#0xFF
   00A4 75 32 FF            516 	mov	(_matrixIntensity + 0x0007),#0xFF
                            517 ;	ledmatrix.c:26: unsigned char matrixLoop = 0;
   00A7 75 33 00            518 	mov	_matrixLoop,#0x00
                            519 ;	gamelogic.c:25: unsigned char posX,posY,game=0,state=STATE_LIST,randomNumber = 0;
   00AA 75 36 00            520 	mov	_game,#0x00
                            521 ;	gamelogic.c:25: 
   00AD 75 37 00            522 	mov	_state,#0x00
                            523 ;	gamelogic.c:25: unsigned char posX,posY,game=0,state=STATE_LIST,randomNumber = 0;
   00B0 75 38 00            524 	mov	_randomNumber,#0x00
                            525 ;	gamelogic.c:33: unsigned char keyAffects = 0;
   00B3 75 3C 00            526 	mov	_keyAffects,#0x00
                            527 ;	gamelogic.c:34: char vX=1, vY=0;
   00B6 75 3D 01            528 	mov	_vX,#0x01
                            529 ;	gamelogic.c:34: // Cantidad de veces que es ejecut� la l�gica
   00B9 75 3E 00            530 	mov	_vY,#0x00
                            531 ;	gamelogic.c:36: unsigned short loop = 0;
   00BC E4                  532 	clr	a
   00BD F5 3F               533 	mov	_loop,a
   00BF F5 40               534 	mov	(_loop + 1),a
                            535 ;	gamelogic.c:38: unsigned char score = 0;
   00C1 75 41 00            536 	mov	_score,#0x00
                            537 ;	gamelogic.c:40: unsigned char buttonUp=0, buttonDown=0, buttonLeft=0, buttonRight=0;
   00C4 75 42 00            538 	mov	_buttonUp,#0x00
                            539 ;	gamelogic.c:40: // Nota actual en la cancion, tiempo actual
   00C7 75 43 00            540 	mov	_buttonDown,#0x00
                            541 ;	gamelogic.c:40: unsigned char buttonUp=0, buttonDown=0, buttonLeft=0, buttonRight=0;
   00CA 75 44 00            542 	mov	_buttonLeft,#0x00
                            543 ;	gamelogic.c:40: // Nota actual en la cancion, tiempo actual
   00CD 75 45 00            544 	mov	_buttonRight,#0x00
                            545 ;	gamelogic.c:42: unsigned char currentNote=0, currentTiming=0;
   00D0 75 46 00            546 	mov	_currentNote,#0x00
                            547 ;	gamelogic.c:42: __code unsigned char song[] 	= "EBCDCB AACEDC BBCDE CAA   DFHH  GFEECE EDCBBC DDECA A  EC DB CA AB EC DB CEH H";
   00D3 75 47 00            548 	mov	_currentTiming,#0x00
                            549 	.area GSFINAL (CODE)
   00D6 02 00 2E            550 	ljmp	__sdcc_program_startup
                            551 ;--------------------------------------------------------
                            552 ; Home
                            553 ;--------------------------------------------------------
                            554 	.area HOME    (CODE)
                            555 	.area HOME    (CODE)
   002E                     556 __sdcc_program_startup:
   002E 12 0A B3            557 	lcall	_main
                            558 ;	return from main will lock up
   0031 80 FE               559 	sjmp .
                            560 ;--------------------------------------------------------
                            561 ; code
                            562 ;--------------------------------------------------------
                            563 	.area CSEG    (CODE)
                            564 ;------------------------------------------------------------
                            565 ;Allocation info for local variables in function 'matrixIsr'
                            566 ;------------------------------------------------------------
                            567 ;tempPtr                   Allocated to registers r7 
                            568 ;------------------------------------------------------------
                            569 ;	ledmatrix.c:28: void matrixIsr() __interrupt(TF0_VECTOR) __using(0)
                            570 ;	-----------------------------------------
                            571 ;	 function matrixIsr
                            572 ;	-----------------------------------------
   00D9                     573 _matrixIsr:
                    0007    574 	ar7 = 0x07
                    0006    575 	ar6 = 0x06
                    0005    576 	ar5 = 0x05
                    0004    577 	ar4 = 0x04
                    0003    578 	ar3 = 0x03
                    0002    579 	ar2 = 0x02
                    0001    580 	ar1 = 0x01
                    0000    581 	ar0 = 0x00
   00D9 C0 E0               582 	push	acc
   00DB C0 82               583 	push	dpl
   00DD C0 83               584 	push	dph
   00DF C0 07               585 	push	ar7
   00E1 C0 01               586 	push	ar1
   00E3 C0 D0               587 	push	psw
   00E5 75 D0 00            588 	mov	psw,#0x00
                            589 ;	ledmatrix.c:30: unsigned char tempPtr = matrixTranslationY[matrixPtr];
   00E8 E5 22               590 	mov	a,_matrixPtr
   00EA 90 0B 27            591 	mov	dptr,#_matrixTranslationY
   00ED 93                  592 	movc	a,@a+dptr
   00EE FF                  593 	mov	r7,a
                            594 ;	ledmatrix.c:33: SHIFTREG_DATA = (matrixPtr == 0)?LEDMATRIX_ROW_ON:LEDMATRIX_ROW_OFF;
   00EF E5 22               595 	mov	a,_matrixPtr
   00F1 24 FF               596 	add	a,#0xff
   00F3 92 90               597 	mov	_P1_0,c
                            598 ;	ledmatrix.c:41: SHIFTREG_CLOCK = 1;
   00F5 D2 92               599 	setb	_P1_2
                            600 ;	ledmatrix.c:42: SHIFTREG_CLOCK = 0;	
   00F7 C2 92               601 	clr	_P1_2
                            602 ;	ledmatrix.c:45: P2 = matrixData[tempPtr];
   00F9 EF                  603 	mov	a,r7
   00FA 24 23               604 	add	a,#_matrixData
   00FC F9                  605 	mov	r1,a
   00FD 87 A0               606 	mov	_P2,@r1
                            607 ;	ledmatrix.c:49: matrixPtr++;
   00FF 05 22               608 	inc	_matrixPtr
                            609 ;	ledmatrix.c:50: matrixPtr&=7;
   0101 53 22 07            610 	anl	_matrixPtr,#0x07
                            611 ;	ledmatrix.c:51: if(matrixPtr == 0) matrixLoop++;
   0104 E5 22               612 	mov	a,_matrixPtr
   0106 70 02               613 	jnz	00102$
   0108 05 33               614 	inc	_matrixLoop
   010A                     615 00102$:
                            616 ;	ledmatrix.c:54: TH0 = (0xFFFF - LEDMATRIX_REDRAW_US) >> 8;
   010A 75 8C FF            617 	mov	_TH0,#0xFF
                            618 ;	ledmatrix.c:55: TL0 = (0xFFFF - LEDMATRIX_REDRAW_US) & 0xFF;
   010D 75 8A 37            619 	mov	_TL0,#0x37
   0110 D0 D0               620 	pop	psw
   0112 D0 01               621 	pop	ar1
   0114 D0 07               622 	pop	ar7
   0116 D0 83               623 	pop	dph
   0118 D0 82               624 	pop	dpl
   011A D0 E0               625 	pop	acc
   011C 32                  626 	reti
                            627 ;	eliminated unneeded push/pop ar0
                            628 ;	eliminated unneeded push/pop b
                            629 ;------------------------------------------------------------
                            630 ;Allocation info for local variables in function 'matrixCls'
                            631 ;------------------------------------------------------------
                            632 ;	ledmatrix.c:59: void matrixCls()
                            633 ;	-----------------------------------------
                            634 ;	 function matrixCls
                            635 ;	-----------------------------------------
   011D                     636 _matrixCls:
                            637 ;	ledmatrix.c:61: matrixData[0] = matrixData[1] = matrixData[2] = matrixData[3] = 
                            638 ;	ledmatrix.c:62: matrixData[4] = matrixData[5] = matrixData[6] = matrixData[7] = 0;
   011D 75 2A 00            639 	mov	(_matrixData + 0x0007),#0x00
   0120 75 29 00            640 	mov	(_matrixData + 0x0006),#0x00
   0123 75 28 00            641 	mov	(_matrixData + 0x0005),#0x00
   0126 75 27 00            642 	mov	(_matrixData + 0x0004),#0x00
   0129 75 26 00            643 	mov	(_matrixData + 0x0003),#0x00
   012C 75 25 00            644 	mov	(_matrixData + 0x0002),#0x00
   012F 75 24 00            645 	mov	(_matrixData + 0x0001),#0x00
   0132 75 23 00            646 	mov	_matrixData,#0x00
   0135 22                  647 	ret
                            648 ;------------------------------------------------------------
                            649 ;Allocation info for local variables in function 'matrixClsI'
                            650 ;------------------------------------------------------------
                            651 ;	ledmatrix.c:65: void matrixClsI()
                            652 ;	-----------------------------------------
                            653 ;	 function matrixClsI
                            654 ;	-----------------------------------------
   0136                     655 _matrixClsI:
                            656 ;	ledmatrix.c:67: matrixIntensity[0] = matrixIntensity[1] = matrixIntensity[2] = matrixIntensity[3] = 
                            657 ;	ledmatrix.c:68: matrixIntensity[4] = matrixIntensity[5] = matrixIntensity[6] = matrixIntensity[7] = 0xFF;
   0136 75 32 FF            658 	mov	(_matrixIntensity + 0x0007),#0xFF
   0139 75 31 FF            659 	mov	(_matrixIntensity + 0x0006),#0xFF
   013C 75 30 FF            660 	mov	(_matrixIntensity + 0x0005),#0xFF
   013F 75 2F FF            661 	mov	(_matrixIntensity + 0x0004),#0xFF
   0142 75 2E FF            662 	mov	(_matrixIntensity + 0x0003),#0xFF
   0145 75 2D FF            663 	mov	(_matrixIntensity + 0x0002),#0xFF
   0148 75 2C FF            664 	mov	(_matrixIntensity + 0x0001),#0xFF
   014B 75 2B FF            665 	mov	_matrixIntensity,#0xFF
   014E 22                  666 	ret
                            667 ;------------------------------------------------------------
                            668 ;Allocation info for local variables in function 'matrixSetsI'
                            669 ;------------------------------------------------------------
                            670 ;	ledmatrix.c:71: void matrixSetsI()
                            671 ;	-----------------------------------------
                            672 ;	 function matrixSetsI
                            673 ;	-----------------------------------------
   014F                     674 _matrixSetsI:
                            675 ;	ledmatrix.c:73: matrixIntensity[0] = matrixIntensity[1] = matrixIntensity[2] = matrixIntensity[3] = 
                            676 ;	ledmatrix.c:74: matrixIntensity[4] = matrixIntensity[5] = matrixIntensity[6] = matrixIntensity[7] = 0x00;
   014F 75 32 00            677 	mov	(_matrixIntensity + 0x0007),#0x00
   0152 75 31 00            678 	mov	(_matrixIntensity + 0x0006),#0x00
   0155 75 30 00            679 	mov	(_matrixIntensity + 0x0005),#0x00
   0158 75 2F 00            680 	mov	(_matrixIntensity + 0x0004),#0x00
   015B 75 2E 00            681 	mov	(_matrixIntensity + 0x0003),#0x00
   015E 75 2D 00            682 	mov	(_matrixIntensity + 0x0002),#0x00
   0161 75 2C 00            683 	mov	(_matrixIntensity + 0x0001),#0x00
   0164 75 2B 00            684 	mov	_matrixIntensity,#0x00
   0167 22                  685 	ret
                            686 ;------------------------------------------------------------
                            687 ;Allocation info for local variables in function 'matrixSets'
                            688 ;------------------------------------------------------------
                            689 ;	ledmatrix.c:77: void matrixSets()
                            690 ;	-----------------------------------------
                            691 ;	 function matrixSets
                            692 ;	-----------------------------------------
   0168                     693 _matrixSets:
                            694 ;	ledmatrix.c:79: matrixData[0] = matrixData[1] = matrixData[2] = matrixData[3] = 
                            695 ;	ledmatrix.c:80: matrixData[4] = matrixData[5] = matrixData[6] = matrixData[7] = 0xFF;
   0168 75 2A FF            696 	mov	(_matrixData + 0x0007),#0xFF
   016B 75 29 FF            697 	mov	(_matrixData + 0x0006),#0xFF
   016E 75 28 FF            698 	mov	(_matrixData + 0x0005),#0xFF
   0171 75 27 FF            699 	mov	(_matrixData + 0x0004),#0xFF
   0174 75 26 FF            700 	mov	(_matrixData + 0x0003),#0xFF
   0177 75 25 FF            701 	mov	(_matrixData + 0x0002),#0xFF
   017A 75 24 FF            702 	mov	(_matrixData + 0x0001),#0xFF
   017D 75 23 FF            703 	mov	_matrixData,#0xFF
   0180 22                  704 	ret
                            705 ;------------------------------------------------------------
                            706 ;Allocation info for local variables in function 'matrixTgls'
                            707 ;------------------------------------------------------------
                            708 ;	ledmatrix.c:83: void matrixTgls()
                            709 ;	-----------------------------------------
                            710 ;	 function matrixTgls
                            711 ;	-----------------------------------------
   0181                     712 _matrixTgls:
                            713 ;	ledmatrix.c:85: matrixData[0] ^= 0xFF; 	matrixData[1] ^= 0xFF;
   0181 74 FF               714 	mov	a,#0xFF
   0183 65 23               715 	xrl	a,_matrixData
   0185 F5 23               716 	mov	_matrixData,a
   0187 74 FF               717 	mov	a,#0xFF
   0189 65 24               718 	xrl	a,(_matrixData + 0x0001)
   018B F5 24               719 	mov	(_matrixData + 0x0001),a
                            720 ;	ledmatrix.c:86: matrixData[2] ^= 0xFF; 	matrixData[3] ^= 0xFF;
   018D 74 FF               721 	mov	a,#0xFF
   018F 65 25               722 	xrl	a,(_matrixData + 0x0002)
   0191 F5 25               723 	mov	(_matrixData + 0x0002),a
   0193 74 FF               724 	mov	a,#0xFF
   0195 65 26               725 	xrl	a,(_matrixData + 0x0003)
   0197 F5 26               726 	mov	(_matrixData + 0x0003),a
                            727 ;	ledmatrix.c:87: matrixData[4] ^= 0xFF; 	matrixData[5] ^= 0xFF;
   0199 74 FF               728 	mov	a,#0xFF
   019B 65 27               729 	xrl	a,(_matrixData + 0x0004)
   019D F5 27               730 	mov	(_matrixData + 0x0004),a
   019F 74 FF               731 	mov	a,#0xFF
   01A1 65 28               732 	xrl	a,(_matrixData + 0x0005)
   01A3 F5 28               733 	mov	(_matrixData + 0x0005),a
                            734 ;	ledmatrix.c:88: matrixData[6] ^= 0xFF; 	matrixData[7] ^= 0xFF;	
   01A5 74 FF               735 	mov	a,#0xFF
   01A7 65 29               736 	xrl	a,(_matrixData + 0x0006)
   01A9 F5 29               737 	mov	(_matrixData + 0x0006),a
   01AB 74 FF               738 	mov	a,#0xFF
   01AD 65 2A               739 	xrl	a,(_matrixData + 0x0007)
   01AF F5 2A               740 	mov	(_matrixData + 0x0007),a
   01B1 22                  741 	ret
                            742 ;------------------------------------------------------------
                            743 ;Allocation info for local variables in function 'matrixSet'
                            744 ;------------------------------------------------------------
                            745 ;y                         Allocated with name '_matrixSet_PARM_2'
                            746 ;x                         Allocated to registers r7 
                            747 ;------------------------------------------------------------
                            748 ;	ledmatrix.c:92: void matrixSet(unsigned char x, unsigned char y)
                            749 ;	-----------------------------------------
                            750 ;	 function matrixSet
                            751 ;	-----------------------------------------
   01B2                     752 _matrixSet:
   01B2 AF 82               753 	mov	r7,dpl
                            754 ;	ledmatrix.c:94: matrixData[y] |= (1<<(7-x));
   01B4 E5 08               755 	mov	a,_matrixSet_PARM_2
   01B6 24 23               756 	add	a,#_matrixData
   01B8 F9                  757 	mov	r1,a
   01B9 87 06               758 	mov	ar6,@r1
   01BB 74 07               759 	mov	a,#0x07
   01BD C3                  760 	clr	c
   01BE 9F                  761 	subb	a,r7
   01BF F5 F0               762 	mov	b,a
   01C1 05 F0               763 	inc	b
   01C3 74 01               764 	mov	a,#0x01
   01C5 80 02               765 	sjmp	00105$
   01C7                     766 00103$:
   01C7 25 E0               767 	add	a,acc
   01C9                     768 00105$:
   01C9 D5 F0 FB            769 	djnz	b,00103$
   01CC 4E                  770 	orl	a,r6
   01CD F7                  771 	mov	@r1,a
   01CE 22                  772 	ret
                            773 ;------------------------------------------------------------
                            774 ;Allocation info for local variables in function 'matrixClr'
                            775 ;------------------------------------------------------------
                            776 ;y                         Allocated with name '_matrixClr_PARM_2'
                            777 ;x                         Allocated to registers r7 
                            778 ;------------------------------------------------------------
                            779 ;	ledmatrix.c:98: void matrixClr(unsigned char x, unsigned char y)
                            780 ;	-----------------------------------------
                            781 ;	 function matrixClr
                            782 ;	-----------------------------------------
   01CF                     783 _matrixClr:
   01CF AF 82               784 	mov	r7,dpl
                            785 ;	ledmatrix.c:100: matrixData[y] &= ~(1<<(7-x));
   01D1 E5 08               786 	mov	a,_matrixClr_PARM_2
   01D3 24 23               787 	add	a,#_matrixData
   01D5 F9                  788 	mov	r1,a
   01D6 87 06               789 	mov	ar6,@r1
   01D8 74 07               790 	mov	a,#0x07
   01DA C3                  791 	clr	c
   01DB 9F                  792 	subb	a,r7
   01DC F5 F0               793 	mov	b,a
   01DE 05 F0               794 	inc	b
   01E0 74 01               795 	mov	a,#0x01
   01E2 80 02               796 	sjmp	00105$
   01E4                     797 00103$:
   01E4 25 E0               798 	add	a,acc
   01E6                     799 00105$:
   01E6 D5 F0 FB            800 	djnz	b,00103$
   01E9 F4                  801 	cpl	a
   01EA 5E                  802 	anl	a,r6
   01EB F7                  803 	mov	@r1,a
   01EC 22                  804 	ret
                            805 ;------------------------------------------------------------
                            806 ;Allocation info for local variables in function 'matrixTgl'
                            807 ;------------------------------------------------------------
                            808 ;y                         Allocated with name '_matrixTgl_PARM_2'
                            809 ;x                         Allocated to registers r7 
                            810 ;------------------------------------------------------------
                            811 ;	ledmatrix.c:104: void matrixTgl(unsigned char x, unsigned char y)
                            812 ;	-----------------------------------------
                            813 ;	 function matrixTgl
                            814 ;	-----------------------------------------
   01ED                     815 _matrixTgl:
   01ED AF 82               816 	mov	r7,dpl
                            817 ;	ledmatrix.c:106: matrixData[y] ^= (1<<(7-x));
   01EF E5 08               818 	mov	a,_matrixTgl_PARM_2
   01F1 24 23               819 	add	a,#_matrixData
   01F3 F9                  820 	mov	r1,a
   01F4 87 06               821 	mov	ar6,@r1
   01F6 74 07               822 	mov	a,#0x07
   01F8 C3                  823 	clr	c
   01F9 9F                  824 	subb	a,r7
   01FA F5 F0               825 	mov	b,a
   01FC 05 F0               826 	inc	b
   01FE 74 01               827 	mov	a,#0x01
   0200 80 02               828 	sjmp	00105$
   0202                     829 00103$:
   0202 25 E0               830 	add	a,acc
   0204                     831 00105$:
   0204 D5 F0 FB            832 	djnz	b,00103$
   0207 6E                  833 	xrl	a,r6
   0208 F7                  834 	mov	@r1,a
   0209 22                  835 	ret
                            836 ;------------------------------------------------------------
                            837 ;Allocation info for local variables in function 'matrixGet'
                            838 ;------------------------------------------------------------
                            839 ;y                         Allocated with name '_matrixGet_PARM_2'
                            840 ;x                         Allocated to registers r7 
                            841 ;------------------------------------------------------------
                            842 ;	ledmatrix.c:110: unsigned char matrixGet(unsigned char x, unsigned char y)
                            843 ;	-----------------------------------------
                            844 ;	 function matrixGet
                            845 ;	-----------------------------------------
   020A                     846 _matrixGet:
   020A AF 82               847 	mov	r7,dpl
                            848 ;	ledmatrix.c:112: return matrixData[y] & (1<<(7-x));
   020C E5 08               849 	mov	a,_matrixGet_PARM_2
   020E 24 23               850 	add	a,#_matrixData
   0210 F9                  851 	mov	r1,a
   0211 87 06               852 	mov	ar6,@r1
   0213 74 07               853 	mov	a,#0x07
   0215 C3                  854 	clr	c
   0216 9F                  855 	subb	a,r7
   0217 F5 F0               856 	mov	b,a
   0219 05 F0               857 	inc	b
   021B 74 01               858 	mov	a,#0x01
   021D 80 02               859 	sjmp	00105$
   021F                     860 00103$:
   021F 25 E0               861 	add	a,acc
   0221                     862 00105$:
   0221 D5 F0 FB            863 	djnz	b,00103$
   0224 5E                  864 	anl	a,r6
   0225 F5 82               865 	mov	dpl,a
   0227 22                  866 	ret
                            867 ;------------------------------------------------------------
                            868 ;Allocation info for local variables in function 'matrixColPut'
                            869 ;------------------------------------------------------------
                            870 ;x                         Allocated with name '_matrixColPut_PARM_2'
                            871 ;y                         Allocated with name '_matrixColPut_PARM_3'
                            872 ;value                     Allocated to registers r7 
                            873 ;retv                      Allocated with name '_matrixColPut_retv_1_16'
                            874 ;------------------------------------------------------------
                            875 ;	ledmatrix.c:116: unsigned char matrixColPut(unsigned char value, unsigned int x, unsigned int y)
                            876 ;	-----------------------------------------
                            877 ;	 function matrixColPut
                            878 ;	-----------------------------------------
   0228                     879 _matrixColPut:
   0228 AF 82               880 	mov	r7,dpl
                            881 ;	ledmatrix.c:118: unsigned char retv=0;
   022A 75 0C 00            882 	mov	_matrixColPut_retv_1_16,#0x00
                            883 ;	ledmatrix.c:119: if(matrixData[y] & (1<<(7-x))) retv = 1;
   022D E5 0A               884 	mov	a,_matrixColPut_PARM_3
   022F 24 23               885 	add	a,#_matrixData
   0231 F9                  886 	mov	r1,a
   0232 87 05               887 	mov	ar5,@r1
   0234 74 07               888 	mov	a,#0x07
   0236 C3                  889 	clr	c
   0237 95 08               890 	subb	a,_matrixColPut_PARM_2
   0239 FB                  891 	mov	r3,a
   023A E4                  892 	clr	a
   023B 95 09               893 	subb	a,(_matrixColPut_PARM_2 + 1)
   023D 8B F0               894 	mov	b,r3
   023F 05 F0               895 	inc	b
   0241 7B 01               896 	mov	r3,#0x01
   0243 7C 00               897 	mov	r4,#0x00
   0245 80 06               898 	sjmp	00113$
   0247                     899 00112$:
   0247 EB                  900 	mov	a,r3
   0248 2B                  901 	add	a,r3
   0249 FB                  902 	mov	r3,a
   024A EC                  903 	mov	a,r4
   024B 33                  904 	rlc	a
   024C FC                  905 	mov	r4,a
   024D                     906 00113$:
   024D D5 F0 F7            907 	djnz	b,00112$
   0250 8D 02               908 	mov	ar2,r5
   0252 7E 00               909 	mov	r6,#0x00
   0254 EB                  910 	mov	a,r3
   0255 52 02               911 	anl	ar2,a
   0257 EC                  912 	mov	a,r4
   0258 52 06               913 	anl	ar6,a
   025A EA                  914 	mov	a,r2
   025B 4E                  915 	orl	a,r6
   025C 60 03               916 	jz	00102$
   025E 75 0C 01            917 	mov	_matrixColPut_retv_1_16,#0x01
   0261                     918 00102$:
                            919 ;	ledmatrix.c:121: if(value)
   0261 EF                  920 	mov	a,r7
   0262 60 18               921 	jz	00104$
                            922 ;	ledmatrix.c:123: matrixData[y] |= (1<<(7-x));
   0264 AF 08               923 	mov	r7,_matrixColPut_PARM_2
   0266 74 07               924 	mov	a,#0x07
   0268 C3                  925 	clr	c
   0269 9F                  926 	subb	a,r7
   026A F5 F0               927 	mov	b,a
   026C 05 F0               928 	inc	b
   026E 74 01               929 	mov	a,#0x01
   0270 80 02               930 	sjmp	00118$
   0272                     931 00116$:
   0272 25 E0               932 	add	a,acc
   0274                     933 00118$:
   0274 D5 F0 FB            934 	djnz	b,00116$
   0277 FF                  935 	mov	r7,a
   0278 4D                  936 	orl	a,r5
   0279 F7                  937 	mov	@r1,a
   027A 80 17               938 	sjmp	00105$
   027C                     939 00104$:
                            940 ;	ledmatrix.c:127: matrixData[y] &= ~(1<<(7-x));
   027C AF 08               941 	mov	r7,_matrixColPut_PARM_2
   027E 74 07               942 	mov	a,#0x07
   0280 C3                  943 	clr	c
   0281 9F                  944 	subb	a,r7
   0282 F5 F0               945 	mov	b,a
   0284 05 F0               946 	inc	b
   0286 74 01               947 	mov	a,#0x01
   0288 80 02               948 	sjmp	00121$
   028A                     949 00119$:
   028A 25 E0               950 	add	a,acc
   028C                     951 00121$:
   028C D5 F0 FB            952 	djnz	b,00119$
   028F F4                  953 	cpl	a
   0290 FF                  954 	mov	r7,a
   0291 5D                  955 	anl	a,r5
   0292 F7                  956 	mov	@r1,a
   0293                     957 00105$:
                            958 ;	ledmatrix.c:129: return retv;
   0293 85 0C 82            959 	mov	dpl,_matrixColPut_retv_1_16
   0296 22                  960 	ret
                            961 ;------------------------------------------------------------
                            962 ;Allocation info for local variables in function 'soundIsr'
                            963 ;------------------------------------------------------------
                            964 ;	sound.c:3: void soundIsr() __interrupt(TF2_VECTOR) __using(0)
                            965 ;	-----------------------------------------
                            966 ;	 function soundIsr
                            967 ;	-----------------------------------------
   0297                     968 _soundIsr:
   0297 C0 D0               969 	push	psw
                            970 ;	sound.c:5: SOUND_PIN = !SOUND_PIN;
   0299 A2 B7               971 	mov	c,_P3_7
   029B B3                  972 	cpl	c
   029C 92 00               973 	mov  _soundIsr_sloc0_1_0,c
   029E 92 B7               974 	mov	_P3_7,c
                            975 ;	sound.c:6: TF2 = 0;	
   02A0 C2 CF               976 	clr	_TF2
   02A2 D0 D0               977 	pop	psw
   02A4 32                  978 	reti
                            979 ;	eliminated unneeded mov psw,# (no regs used in bank)
                            980 ;	eliminated unneeded push/pop dpl
                            981 ;	eliminated unneeded push/pop dph
                            982 ;	eliminated unneeded push/pop b
                            983 ;	eliminated unneeded push/pop acc
                            984 ;------------------------------------------------------------
                            985 ;Allocation info for local variables in function 'soundStop'
                            986 ;------------------------------------------------------------
                            987 ;	sound.c:9: void soundStop()
                            988 ;	-----------------------------------------
                            989 ;	 function soundStop
                            990 ;	-----------------------------------------
   02A5                     991 _soundStop:
                            992 ;	sound.c:11: ET2 = 0;
   02A5 C2 AD               993 	clr	_ET2
                            994 ;	sound.c:12: SOUND_PIN = 0;
   02A7 C2 B7               995 	clr	_P3_7
   02A9 22                  996 	ret
                            997 ;------------------------------------------------------------
                            998 ;Allocation info for local variables in function 'soundPlay'
                            999 ;------------------------------------------------------------
                           1000 ;note                      Allocated to registers r7 
                           1001 ;------------------------------------------------------------
                           1002 ;	sound.c:34: void soundPlay(unsigned char note)
                           1003 ;	-----------------------------------------
                           1004 ;	 function soundPlay
                           1005 ;	-----------------------------------------
   02AA                    1006 _soundPlay:
                           1007 ;	sound.c:36: RCAP2H = soundNotes[note] >> 8;
   02AA E5 82              1008 	mov	a,dpl
   02AC 25 82              1009 	add	a,dpl
   02AE FE                 1010 	mov	r6,a
   02AF 90 0B 2F           1011 	mov	dptr,#_soundNotes
   02B2 93                 1012 	movc	a,@a+dptr
   02B3 CE                 1013 	xch	a,r6
   02B4 A3                 1014 	inc	dptr
   02B5 93                 1015 	movc	a,@a+dptr
   02B6 FF                 1016 	mov	r7,a
   02B7 8F CB              1017 	mov	_RCAP2H,r7
                           1018 ;	sound.c:37: RCAP2L = soundNotes[note] & 0xFF;
   02B9 8E CA              1019 	mov	_RCAP2L,r6
                           1020 ;	sound.c:38: ET2 = 1;
   02BB D2 AD              1021 	setb	_ET2
   02BD 22                 1022 	ret
                           1023 ;------------------------------------------------------------
                           1024 ;Allocation info for local variables in function 'leftIsr'
                           1025 ;------------------------------------------------------------
                           1026 ;	gamelogic.c:61: void leftIsr() __interrupt(IE0_VECTOR) __using(0)
                           1027 ;	-----------------------------------------
                           1028 ;	 function leftIsr
                           1029 ;	-----------------------------------------
   02BE                    1030 _leftIsr:
                           1031 ;	gamelogic.c:63: randomNumber = TL0;
   02BE 85 8A 38           1032 	mov	_randomNumber,_TL0
   02C1 32                 1033 	reti
                           1034 ;	eliminated unneeded mov psw,# (no regs used in bank)
                           1035 ;	eliminated unneeded push/pop psw
                           1036 ;	eliminated unneeded push/pop dpl
                           1037 ;	eliminated unneeded push/pop dph
                           1038 ;	eliminated unneeded push/pop b
                           1039 ;	eliminated unneeded push/pop acc
                           1040 ;------------------------------------------------------------
                           1041 ;Allocation info for local variables in function 'upIsr'
                           1042 ;------------------------------------------------------------
                           1043 ;	gamelogic.c:65: void upIsr() __interrupt(IE1_VECTOR) __using(0)
                           1044 ;	-----------------------------------------
                           1045 ;	 function upIsr
                           1046 ;	-----------------------------------------
   02C2                    1047 _upIsr:
                           1048 ;	gamelogic.c:67: randomNumber = TL0;
   02C2 85 8A 38           1049 	mov	_randomNumber,_TL0
   02C5 32                 1050 	reti
                           1051 ;	eliminated unneeded mov psw,# (no regs used in bank)
                           1052 ;	eliminated unneeded push/pop psw
                           1053 ;	eliminated unneeded push/pop dpl
                           1054 ;	eliminated unneeded push/pop dph
                           1055 ;	eliminated unneeded push/pop b
                           1056 ;	eliminated unneeded push/pop acc
                           1057 ;------------------------------------------------------------
                           1058 ;Allocation info for local variables in function 'getRandomNumber'
                           1059 ;------------------------------------------------------------
                           1060 ;	gamelogic.c:71: unsigned char getRandomNumber()
                           1061 ;	-----------------------------------------
                           1062 ;	 function getRandomNumber
                           1063 ;	-----------------------------------------
   02C6                    1064 _getRandomNumber:
                           1065 ;	gamelogic.c:73: randomNumber=randomNumber*9+7;
   02C6 E5 38              1066 	mov	a,_randomNumber
   02C8 75 F0 09           1067 	mov	b,#0x09
   02CB A4                 1068 	mul	ab
   02CC 24 07              1069 	add	a,#0x07
   02CE F5 38              1070 	mov	_randomNumber,a
                           1071 ;	gamelogic.c:74: return randomNumber;
   02D0 85 38 82           1072 	mov	dpl,_randomNumber
   02D3 22                 1073 	ret
                           1074 ;------------------------------------------------------------
                           1075 ;Allocation info for local variables in function 'gameOver'
                           1076 ;------------------------------------------------------------
                           1077 ;num1                      Allocated to registers r7 
                           1078 ;num2                      Allocated to registers r6 
                           1079 ;sloc0                     Allocated with name '_gameOver_sloc0_1_0'
                           1080 ;------------------------------------------------------------
                           1081 ;	gamelogic.c:77: void gameOver(){
                           1082 ;	-----------------------------------------
                           1083 ;	 function gameOver
                           1084 ;	-----------------------------------------
   02D4                    1085 _gameOver:
                           1086 ;	gamelogic.c:80: soundStop();
   02D4 12 02 A5           1087 	lcall	_soundStop
                           1088 ;	gamelogic.c:81: matrixCls();
   02D7 12 01 1D           1089 	lcall	_matrixCls
                           1090 ;	gamelogic.c:82: num1 = score/10;
   02DA 75 F0 0A           1091 	mov	b,#0x0A
   02DD E5 41              1092 	mov	a,_score
   02DF 84                 1093 	div	ab
   02E0 FF                 1094 	mov	r7,a
                           1095 ;	gamelogic.c:83: num2 = score%10;
   02E1 75 F0 0A           1096 	mov	b,#0x0A
   02E4 E5 41              1097 	mov	a,_score
   02E6 84                 1098 	div	ab
                           1099 ;	gamelogic.c:84: matrixData[0] = fuente[num2*5];
   02E7 E5 F0              1100 	mov	a,b
   02E9 FE                 1101 	mov	r6,a
   02EA 75 F0 05           1102 	mov	b,#0x05
   02ED A4                 1103 	mul	ab
   02EE 90 0B EB           1104 	mov	dptr,#_fuente
   02F1 93                 1105 	movc	a,@a+dptr
   02F2 FD                 1106 	mov	r5,a
   02F3 8D 23              1107 	mov	_matrixData,r5
                           1108 ;	gamelogic.c:85: matrixData[1] = fuente[num2*5+1];
   02F5 EE                 1109 	mov	a,r6
   02F6 75 F0 05           1110 	mov	b,#0x05
   02F9 A4                 1111 	mul	ab
   02FA FE                 1112 	mov	r6,a
   02FB 04                 1113 	inc	a
   02FC 90 0B EB           1114 	mov	dptr,#_fuente
   02FF 93                 1115 	movc	a,@a+dptr
   0300 FC                 1116 	mov	r4,a
   0301 8C 24              1117 	mov	(_matrixData + 0x0001),r4
                           1118 ;	gamelogic.c:86: matrixData[2] = fuente[num2*5+2];
   0303 74 02              1119 	mov	a,#0x02
   0305 2E                 1120 	add	a,r6
   0306 90 0B EB           1121 	mov	dptr,#_fuente
   0309 93                 1122 	movc	a,@a+dptr
   030A FB                 1123 	mov	r3,a
   030B 8B 25              1124 	mov	(_matrixData + 0x0002),r3
                           1125 ;	gamelogic.c:87: matrixData[3] = fuente[num2*5+3];
   030D 74 03              1126 	mov	a,#0x03
   030F 2E                 1127 	add	a,r6
   0310 90 0B EB           1128 	mov	dptr,#_fuente
   0313 93                 1129 	movc	a,@a+dptr
   0314 FA                 1130 	mov	r2,a
   0315 8A 26              1131 	mov	(_matrixData + 0x0003),r2
                           1132 ;	gamelogic.c:88: matrixData[4] = fuente[num2*5+4];
   0317 74 04              1133 	mov	a,#0x04
   0319 2E                 1134 	add	a,r6
   031A 90 0B EB           1135 	mov	dptr,#_fuente
   031D 93                 1136 	movc	a,@a+dptr
   031E F5 48              1137 	mov	_gameOver_sloc0_1_0,a
   0320 85 48 27           1138 	mov	(_matrixData + 0x0004),_gameOver_sloc0_1_0
                           1139 ;	gamelogic.c:90: matrixData[0] |= fuente[num1*5]<<4;
   0323 EF                 1140 	mov	a,r7
   0324 75 F0 05           1141 	mov	b,#0x05
   0327 A4                 1142 	mul	ab
   0328 FF                 1143 	mov	r7,a
   0329 90 0B EB           1144 	mov	dptr,#_fuente
   032C 93                 1145 	movc	a,@a+dptr
   032D C4                 1146 	swap	a
   032E 54 F0              1147 	anl	a,#0xF0
   0330 4D                 1148 	orl	a,r5
   0331 F5 23              1149 	mov	_matrixData,a
                           1150 ;	gamelogic.c:91: matrixData[1] |= fuente[num1*5+1]<<4;
   0333 EF                 1151 	mov	a,r7
   0334 04                 1152 	inc	a
   0335 90 0B EB           1153 	mov	dptr,#_fuente
   0338 93                 1154 	movc	a,@a+dptr
   0339 C4                 1155 	swap	a
   033A 54 F0              1156 	anl	a,#0xF0
   033C 4C                 1157 	orl	a,r4
   033D F5 24              1158 	mov	(_matrixData + 0x0001),a
                           1159 ;	gamelogic.c:92: matrixData[2] |= fuente[num1*5+2]<<4;
   033F 74 02              1160 	mov	a,#0x02
   0341 2F                 1161 	add	a,r7
   0342 90 0B EB           1162 	mov	dptr,#_fuente
   0345 93                 1163 	movc	a,@a+dptr
   0346 C4                 1164 	swap	a
   0347 54 F0              1165 	anl	a,#0xF0
   0349 4B                 1166 	orl	a,r3
   034A F5 25              1167 	mov	(_matrixData + 0x0002),a
                           1168 ;	gamelogic.c:93: matrixData[3] |= fuente[num1*5+3]<<4;
   034C 74 03              1169 	mov	a,#0x03
   034E 2F                 1170 	add	a,r7
   034F 90 0B EB           1171 	mov	dptr,#_fuente
   0352 93                 1172 	movc	a,@a+dptr
   0353 C4                 1173 	swap	a
   0354 54 F0              1174 	anl	a,#0xF0
   0356 4A                 1175 	orl	a,r2
   0357 F5 26              1176 	mov	(_matrixData + 0x0003),a
                           1177 ;	gamelogic.c:94: matrixData[4] |= fuente[num1*5+4]<<4;
   0359 74 04              1178 	mov	a,#0x04
   035B 2F                 1179 	add	a,r7
   035C 90 0B EB           1180 	mov	dptr,#_fuente
   035F 93                 1181 	movc	a,@a+dptr
   0360 C4                 1182 	swap	a
   0361 54 F0              1183 	anl	a,#0xF0
   0363 45 48              1184 	orl	a,_gameOver_sloc0_1_0
   0365 F5 27              1185 	mov	(_matrixData + 0x0004),a
                           1186 ;	gamelogic.c:97: state = STATE_GAMEOVER;
   0367 75 37 01           1187 	mov	_state,#0x01
   036A 22                 1188 	ret
                           1189 ;------------------------------------------------------------
                           1190 ;Allocation info for local variables in function 'gameList'
                           1191 ;------------------------------------------------------------
                           1192 ;	gamelogic.c:100: void gameList()
                           1193 ;	-----------------------------------------
                           1194 ;	 function gameList
                           1195 ;	-----------------------------------------
   036B                    1196 _gameList:
                           1197 ;	gamelogic.c:102: matrixClsI();
   036B 12 01 36           1198 	lcall	_matrixClsI
                           1199 ;	gamelogic.c:104: switch(game)
   036E E5 36              1200 	mov	a,_game
   0370 24 FB              1201 	add	a,#0xff - 0x04
   0372 50 03              1202 	jnc	00132$
   0374 02 04 10           1203 	ljmp	00106$
   0377                    1204 00132$:
   0377 E5 36              1205 	mov	a,_game
   0379 75 F0 03           1206 	mov	b,#0x03
   037C A4                 1207 	mul	ab
   037D 90 03 81           1208 	mov	dptr,#00133$
   0380 73                 1209 	jmp	@a+dptr
   0381                    1210 00133$:
   0381 02 03 90           1211 	ljmp	00101$
   0384 02 03 AA           1212 	ljmp	00102$
   0387 02 03 C4           1213 	ljmp	00103$
   038A 02 03 DE           1214 	ljmp	00104$
   038D 02 03 F8           1215 	ljmp	00105$
                           1216 ;	gamelogic.c:106: case 0:
   0390                    1217 00101$:
                           1218 ;	gamelogic.c:107: matrixData[0] = 0b01110111;
   0390 75 23 77           1219 	mov	_matrixData,#0x77
                           1220 ;	gamelogic.c:108: matrixData[1] = 0b00100100;
   0393 75 24 24           1221 	mov	(_matrixData + 0x0001),#0x24
                           1222 ;	gamelogic.c:109: matrixData[2] = 0b00100111;
   0396 75 25 27           1223 	mov	(_matrixData + 0x0002),#0x27
                           1224 ;	gamelogic.c:110: matrixData[3] = 0b00100100;
   0399 75 26 24           1225 	mov	(_matrixData + 0x0003),#0x24
                           1226 ;	gamelogic.c:111: matrixData[4] = 0b00100111;
   039C 75 27 27           1227 	mov	(_matrixData + 0x0004),#0x27
                           1228 ;	gamelogic.c:112: matrixData[5] = 0b00000000;
   039F 75 28 00           1229 	mov	(_matrixData + 0x0005),#0x00
                           1230 ;	gamelogic.c:113: matrixData[6] = 0b00000000;
   03A2 75 29 00           1231 	mov	(_matrixData + 0x0006),#0x00
                           1232 ;	gamelogic.c:114: matrixData[7] = 0b00000000;
   03A5 75 2A 00           1233 	mov	(_matrixData + 0x0007),#0x00
                           1234 ;	gamelogic.c:115: break;
                           1235 ;	gamelogic.c:116: case 1:
   03A8 80 66              1236 	sjmp	00106$
   03AA                    1237 00102$:
                           1238 ;	gamelogic.c:117: matrixData[0] = 0b01110101;
   03AA 75 23 75           1239 	mov	_matrixData,#0x75
                           1240 ;	gamelogic.c:118: matrixData[1] = 0b01010101;
   03AD 75 24 55           1241 	mov	(_matrixData + 0x0001),#0x55
                           1242 ;	gamelogic.c:119: matrixData[2] = 0b01110101;
   03B0 75 25 75           1243 	mov	(_matrixData + 0x0002),#0x75
                           1244 ;	gamelogic.c:120: matrixData[3] = 0b01010101;
   03B3 75 26 55           1245 	mov	(_matrixData + 0x0003),#0x55
                           1246 ;	gamelogic.c:121: matrixData[4] = 0b01010111;
   03B6 75 27 57           1247 	mov	(_matrixData + 0x0004),#0x57
                           1248 ;	gamelogic.c:122: matrixData[5] = 0b00000000;
   03B9 75 28 00           1249 	mov	(_matrixData + 0x0005),#0x00
                           1250 ;	gamelogic.c:123: matrixData[6] = 0b00000000;
   03BC 75 29 00           1251 	mov	(_matrixData + 0x0006),#0x00
                           1252 ;	gamelogic.c:124: matrixData[7] = 0b00000000;					
   03BF 75 2A 00           1253 	mov	(_matrixData + 0x0007),#0x00
                           1254 ;	gamelogic.c:125: break;
                           1255 ;	gamelogic.c:126: case 2:
   03C2 80 4C              1256 	sjmp	00106$
   03C4                    1257 00103$:
                           1258 ;	gamelogic.c:127: matrixData[0] = 0b01110101;
   03C4 75 23 75           1259 	mov	_matrixData,#0x75
                           1260 ;	gamelogic.c:128: matrixData[1] = 0b01000101;
   03C7 75 24 45           1261 	mov	(_matrixData + 0x0001),#0x45
                           1262 ;	gamelogic.c:129: matrixData[2] = 0b01000111;
   03CA 75 25 47           1263 	mov	(_matrixData + 0x0002),#0x47
                           1264 ;	gamelogic.c:130: matrixData[3] = 0b01000101;
   03CD 75 26 45           1265 	mov	(_matrixData + 0x0003),#0x45
                           1266 ;	gamelogic.c:131: matrixData[4] = 0b01110101;
   03D0 75 27 75           1267 	mov	(_matrixData + 0x0004),#0x75
                           1268 ;	gamelogic.c:132: matrixData[5] = 0b00000000;
   03D3 75 28 00           1269 	mov	(_matrixData + 0x0005),#0x00
                           1270 ;	gamelogic.c:133: matrixData[6] = 0b00000000;
   03D6 75 29 00           1271 	mov	(_matrixData + 0x0006),#0x00
                           1272 ;	gamelogic.c:134: matrixData[7] = 0b00000000;					
   03D9 75 2A 00           1273 	mov	(_matrixData + 0x0007),#0x00
                           1274 ;	gamelogic.c:135: break;
                           1275 ;	gamelogic.c:136: case 3:
   03DC 80 32              1276 	sjmp	00106$
   03DE                    1277 00104$:
                           1278 ;	gamelogic.c:137: matrixData[0] = 0b11101001;
   03DE 75 23 E9           1279 	mov	_matrixData,#0xE9
                           1280 ;	gamelogic.c:138: matrixData[1] = 0b10001101;
   03E1 75 24 8D           1281 	mov	(_matrixData + 0x0001),#0x8D
                           1282 ;	gamelogic.c:139: matrixData[2] = 0b11101011;
   03E4 75 25 EB           1283 	mov	(_matrixData + 0x0002),#0xEB
                           1284 ;	gamelogic.c:140: matrixData[3] = 0b00101001;
   03E7 75 26 29           1285 	mov	(_matrixData + 0x0003),#0x29
                           1286 ;	gamelogic.c:141: matrixData[4] = 0b11101001;
   03EA 75 27 E9           1287 	mov	(_matrixData + 0x0004),#0xE9
                           1288 ;	gamelogic.c:142: matrixData[5] = 0b00000000;
   03ED 75 28 00           1289 	mov	(_matrixData + 0x0005),#0x00
                           1290 ;	gamelogic.c:143: matrixData[6] = 0b00000000;
   03F0 75 29 00           1291 	mov	(_matrixData + 0x0006),#0x00
                           1292 ;	gamelogic.c:144: matrixData[7] = 0b00000000;									
   03F3 75 2A 00           1293 	mov	(_matrixData + 0x0007),#0x00
                           1294 ;	gamelogic.c:145: break;
                           1295 ;	gamelogic.c:146: case 4:
   03F6 80 18              1296 	sjmp	00106$
   03F8                    1297 00105$:
                           1298 ;	gamelogic.c:147: matrixData[0] = 0b11101001;
   03F8 75 23 E9           1299 	mov	_matrixData,#0xE9
                           1300 ;	gamelogic.c:148: matrixData[1] = 0b10001001;
   03FB 75 24 89           1301 	mov	(_matrixData + 0x0001),#0x89
                           1302 ;	gamelogic.c:149: matrixData[2] = 0b11101001;
   03FE 75 25 E9           1303 	mov	(_matrixData + 0x0002),#0xE9
                           1304 ;	gamelogic.c:150: matrixData[3] = 0b10101001;
   0401 75 26 A9           1305 	mov	(_matrixData + 0x0003),#0xA9
                           1306 ;	gamelogic.c:151: matrixData[4] = 0b11101111;
   0404 75 27 EF           1307 	mov	(_matrixData + 0x0004),#0xEF
                           1308 ;	gamelogic.c:152: matrixData[5] = 0b00000000;
   0407 75 28 00           1309 	mov	(_matrixData + 0x0005),#0x00
                           1310 ;	gamelogic.c:153: matrixData[6] = 0b00000000;
   040A 75 29 00           1311 	mov	(_matrixData + 0x0006),#0x00
                           1312 ;	gamelogic.c:154: matrixData[7] = 0b00000000;									
   040D 75 2A 00           1313 	mov	(_matrixData + 0x0007),#0x00
                           1314 ;	gamelogic.c:156: }
   0410                    1315 00106$:
                           1316 ;	gamelogic.c:157: if(BTN_LEFT)
   0410 20 B5 14           1317 	jb	_P3_5,00110$
                           1318 ;	gamelogic.c:159: if(buttonLeft == 0)
   0413 E5 44              1319 	mov	a,_buttonLeft
   0415 70 13              1320 	jnz	00111$
                           1321 ;	gamelogic.c:161: buttonLeft = 1;
   0417 75 44 01           1322 	mov	_buttonLeft,#0x01
                           1323 ;	gamelogic.c:163: game++;
   041A 05 36              1324 	inc	_game
                           1325 ;	gamelogic.c:165: game%=AMOUNT_GAMES;
   041C 75 F0 05           1326 	mov	b,#0x05
   041F E5 36              1327 	mov	a,_game
   0421 84                 1328 	div	ab
   0422 85 F0 36           1329 	mov	_game,b
   0425 80 03              1330 	sjmp	00111$
   0427                    1331 00110$:
                           1332 ;	gamelogic.c:170: buttonLeft = 0;
   0427 75 44 00           1333 	mov	_buttonLeft,#0x00
   042A                    1334 00111$:
                           1335 ;	gamelogic.c:173: if(BTN_RIGHT)
   042A 30 B3 01           1336 	jnb	_P3_3,00136$
   042D 22                 1337 	ret
   042E                    1338 00136$:
                           1339 ;	gamelogic.c:178: score=0;
   042E 75 41 00           1340 	mov	_score,#0x00
                           1341 ;	gamelogic.c:179: switch(game)
   0431 E5 36              1342 	mov	a,_game
   0433 24 FB              1343 	add	a,#0xff - 0x04
   0435 40 71              1344 	jc	00120$
   0437 E5 36              1345 	mov	a,_game
   0439 75 F0 03           1346 	mov	b,#0x03
   043C A4                 1347 	mul	ab
   043D 90 04 41           1348 	mov	dptr,#00138$
   0440 73                 1349 	jmp	@a+dptr
   0441                    1350 00138$:
   0441 02 04 50           1351 	ljmp	00112$
   0444 02 04 5D           1352 	ljmp	00113$
   0447 02 04 70           1353 	ljmp	00114$
   044A 02 04 7D           1354 	ljmp	00115$
   044D 02 04 A2           1355 	ljmp	00116$
                           1356 ;	gamelogic.c:181: case 0:
   0450                    1357 00112$:
                           1358 ;	gamelogic.c:182: matrixCls();					
   0450 12 01 1D           1359 	lcall	_matrixCls
                           1360 ;	gamelogic.c:183: state = STATE_TETRIS;
   0453 75 37 02           1361 	mov	_state,#0x02
                           1362 ;	gamelogic.c:184: posX = 3;
   0456 75 34 03           1363 	mov	_posX,#0x03
                           1364 ;	gamelogic.c:185: posY = 0;
   0459 75 35 00           1365 	mov	_posY,#0x00
                           1366 ;	gamelogic.c:186: break;	
                           1367 ;	gamelogic.c:187: case 1:				
   045C 22                 1368 	ret
   045D                    1369 00113$:
                           1370 ;	gamelogic.c:188: matrixCls();
   045D 12 01 1D           1371 	lcall	_matrixCls
                           1372 ;	gamelogic.c:189: state = STATE_CAR;
   0460 75 37 03           1373 	mov	_state,#0x03
                           1374 ;	gamelogic.c:190: matrixSetsI();
   0463 12 01 4F           1375 	lcall	_matrixSetsI
                           1376 ;	gamelogic.c:191: posX = 3;
   0466 75 34 03           1377 	mov	_posX,#0x03
                           1378 ;	gamelogic.c:192: posY = 7;
   0469 75 35 07           1379 	mov	_posY,#0x07
                           1380 ;	gamelogic.c:193: matrixData[0] = 0b11100011;
   046C 75 23 E3           1381 	mov	_matrixData,#0xE3
                           1382 ;	gamelogic.c:194: break;
                           1383 ;	gamelogic.c:195: case 2:
   046F 22                 1384 	ret
   0470                    1385 00114$:
                           1386 ;	gamelogic.c:196: matrixCls();
   0470 12 01 1D           1387 	lcall	_matrixCls
                           1388 ;	gamelogic.c:197: state = STATE_CHOPPER;
   0473 75 37 04           1389 	mov	_state,#0x04
                           1390 ;	gamelogic.c:198: posX = 0;
   0476 75 34 00           1391 	mov	_posX,#0x00
                           1392 ;	gamelogic.c:199: posY = 3;
   0479 75 35 03           1393 	mov	_posY,#0x03
                           1394 ;	gamelogic.c:200: break;					
                           1395 ;	gamelogic.c:201: case 3:
   047C 22                 1396 	ret
   047D                    1397 00115$:
                           1398 ;	gamelogic.c:202: matrixCls();
   047D 12 01 1D           1399 	lcall	_matrixCls
                           1400 ;	gamelogic.c:203: state = STATE_SNAKE;
   0480 75 37 05           1401 	mov	_state,#0x05
                           1402 ;	gamelogic.c:204: fruitX = getRandomNumber()%8;
   0483 12 02 C6           1403 	lcall	_getRandomNumber
   0486 E5 82              1404 	mov	a,dpl
   0488 54 07              1405 	anl	a,#0x07
   048A F5 39              1406 	mov	_fruitX,a
                           1407 ;	gamelogic.c:205: fruitY = getRandomNumber()%8;
   048C 12 02 C6           1408 	lcall	_getRandomNumber
   048F E5 82              1409 	mov	a,dpl
   0491 54 07              1410 	anl	a,#0x07
   0493 F5 3A              1411 	mov	_fruitY,a
                           1412 ;	gamelogic.c:206: matrixSet(fruitX,fruitY);
   0495 85 3A 08           1413 	mov	_matrixSet_PARM_2,_fruitY
   0498 85 39 82           1414 	mov	dpl,_fruitX
   049B 12 01 B2           1415 	lcall	_matrixSet
                           1416 ;	gamelogic.c:207: snakeLen = 1;
   049E 75 3B 01           1417 	mov	_snakeLen,#0x01
                           1418 ;	gamelogic.c:208: break;						
                           1419 ;	gamelogic.c:209: case 4:	
   04A1 22                 1420 	ret
   04A2                    1421 00116$:
                           1422 ;	gamelogic.c:210: matrixCls();
   04A2 12 01 1D           1423 	lcall	_matrixCls
                           1424 ;	gamelogic.c:211: state = STATE_GUITAR;
   04A5 75 37 06           1425 	mov	_state,#0x06
                           1426 ;	gamelogic.c:213: }
   04A8                    1427 00120$:
   04A8 22                 1428 	ret
                           1429 ;------------------------------------------------------------
                           1430 ;Allocation info for local variables in function 'gameTetris'
                           1431 ;------------------------------------------------------------
                           1432 ;i                         Allocated to registers r7 
                           1433 ;------------------------------------------------------------
                           1434 ;	gamelogic.c:217: void gameTetris(){
                           1435 ;	-----------------------------------------
                           1436 ;	 function gameTetris
                           1437 ;	-----------------------------------------
   04A9                    1438 _gameTetris:
                           1439 ;	gamelogic.c:220: matrixClr(posX, posY);
   04A9 85 35 08           1440 	mov	_matrixClr_PARM_2,_posY
   04AC 85 34 82           1441 	mov	dpl,_posX
   04AF 12 01 CF           1442 	lcall	_matrixClr
                           1443 ;	gamelogic.c:222: if(BTN_LEFT)
   04B2 20 B5 21           1444 	jb	_P3_5,00107$
                           1445 ;	gamelogic.c:224: if(buttonLeft == 0)
   04B5 E5 44              1446 	mov	a,_buttonLeft
   04B7 70 20              1447 	jnz	00108$
                           1448 ;	gamelogic.c:226: randomNumber = TL1;
   04B9 85 8B 38           1449 	mov	_randomNumber,_TL1
                           1450 ;	gamelogic.c:227: buttonLeft = 1;
   04BC 75 44 01           1451 	mov	_buttonLeft,#0x01
                           1452 ;	gamelogic.c:228: if(posX!=0 && !matrixGet(posX-1,posY)) posX--;
   04BF E5 34              1453 	mov	a,_posX
   04C1 60 16              1454 	jz	00108$
   04C3 E5 34              1455 	mov	a,_posX
   04C5 14                 1456 	dec	a
   04C6 F5 82              1457 	mov	dpl,a
   04C8 85 35 08           1458 	mov	_matrixGet_PARM_2,_posY
   04CB 12 02 0A           1459 	lcall	_matrixGet
   04CE E5 82              1460 	mov	a,dpl
   04D0 70 07              1461 	jnz	00108$
   04D2 15 34              1462 	dec	_posX
   04D4 80 03              1463 	sjmp	00108$
   04D6                    1464 00107$:
                           1465 ;	gamelogic.c:232: buttonLeft = 0;
   04D6 75 44 00           1466 	mov	_buttonLeft,#0x00
   04D9                    1467 00108$:
                           1468 ;	gamelogic.c:235: if(BTN_RIGHT)
   04D9 20 B3 24           1469 	jb	_P3_3,00115$
                           1470 ;	gamelogic.c:237: if(buttonRight == 0)
   04DC E5 45              1471 	mov	a,_buttonRight
   04DE 70 23              1472 	jnz	00116$
                           1473 ;	gamelogic.c:239: randomNumber = TL1;
   04E0 85 8B 38           1474 	mov	_randomNumber,_TL1
                           1475 ;	gamelogic.c:240: buttonRight = 1;
   04E3 75 45 01           1476 	mov	_buttonRight,#0x01
                           1477 ;	gamelogic.c:241: if(posX!=7 && !matrixGet(posX+1,posY)) posX++;
   04E6 74 07              1478 	mov	a,#0x07
   04E8 B5 34 02           1479 	cjne	a,_posX,00187$
   04EB 80 16              1480 	sjmp	00116$
   04ED                    1481 00187$:
   04ED E5 34              1482 	mov	a,_posX
   04EF 04                 1483 	inc	a
   04F0 F5 82              1484 	mov	dpl,a
   04F2 85 35 08           1485 	mov	_matrixGet_PARM_2,_posY
   04F5 12 02 0A           1486 	lcall	_matrixGet
   04F8 E5 82              1487 	mov	a,dpl
   04FA 70 07              1488 	jnz	00116$
   04FC 05 34              1489 	inc	_posX
   04FE 80 03              1490 	sjmp	00116$
   0500                    1491 00115$:
                           1492 ;	gamelogic.c:245: buttonRight = 0;
   0500 75 45 00           1493 	mov	_buttonRight,#0x00
   0503                    1494 00116$:
                           1495 ;	gamelogic.c:247: matrixSet(posX, posY);
   0503 85 35 08           1496 	mov	_matrixSet_PARM_2,_posY
   0506 85 34 82           1497 	mov	dpl,_posX
   0509 12 01 B2           1498 	lcall	_matrixSet
                           1499 ;	gamelogic.c:251: if(loop%5 == 0)
   050C 75 08 05           1500 	mov	__moduint_PARM_2,#0x05
   050F 75 09 00           1501 	mov	(__moduint_PARM_2 + 1),#0x00
   0512 85 3F 82           1502 	mov	dpl,_loop
   0515 85 40 83           1503 	mov	dph,(_loop + 1)
   0518 12 0A D6           1504 	lcall	__moduint
   051B E5 82              1505 	mov	a,dpl
   051D 85 83 F0           1506 	mov	b,dph
   0520 45 F0              1507 	orl	a,b
   0522 70 6C              1508 	jnz	00126$
                           1509 ;	gamelogic.c:254: matrixClr(posX, posY);		
   0524 85 35 08           1510 	mov	_matrixClr_PARM_2,_posY
   0527 85 34 82           1511 	mov	dpl,_posX
   052A 12 01 CF           1512 	lcall	_matrixClr
                           1513 ;	gamelogic.c:257: if(posY!=7 && !matrixGet(posX,posY+1))
   052D 74 07              1514 	mov	a,#0x07
   052F B5 35 02           1515 	cjne	a,_posY,00190$
   0532 80 13              1516 	sjmp	00120$
   0534                    1517 00190$:
   0534 E5 35              1518 	mov	a,_posY
   0536 04                 1519 	inc	a
   0537 F5 08              1520 	mov	_matrixGet_PARM_2,a
   0539 85 34 82           1521 	mov	dpl,_posX
   053C 12 02 0A           1522 	lcall	_matrixGet
   053F E5 82              1523 	mov	a,dpl
   0541 70 04              1524 	jnz	00120$
                           1525 ;	gamelogic.c:259: posY++;	
   0543 05 35              1526 	inc	_posY
   0545 80 30              1527 	sjmp	00121$
   0547                    1528 00120$:
                           1529 ;	gamelogic.c:264: matrixSet(posX, posY);
   0547 85 35 08           1530 	mov	_matrixSet_PARM_2,_posY
   054A 85 34 82           1531 	mov	dpl,_posX
   054D 12 01 B2           1532 	lcall	_matrixSet
                           1533 ;	gamelogic.c:267: if(matrixData[7] == 0xFF)
   0550 74 FF              1534 	mov	a,#0xFF
   0552 B5 2A 1C           1535 	cjne	a,(_matrixData + 0x0007),00118$
                           1536 ;	gamelogic.c:270: for(i=7;i>0;i--) matrixData[i] = matrixData[i-1];
   0555 7F 07              1537 	mov	r7,#0x07
   0557                    1538 00135$:
   0557 EF                 1539 	mov	a,r7
   0558 60 12              1540 	jz	00138$
   055A EF                 1541 	mov	a,r7
   055B 24 23              1542 	add	a,#_matrixData
   055D F9                 1543 	mov	r1,a
   055E EF                 1544 	mov	a,r7
   055F 14                 1545 	dec	a
   0560 FE                 1546 	mov	r6,a
   0561 24 23              1547 	add	a,#_matrixData
   0563 F8                 1548 	mov	r0,a
   0564 86 05              1549 	mov	ar5,@r0
   0566 A7 05              1550 	mov	@r1,ar5
   0568 8E 07              1551 	mov	ar7,r6
   056A 80 EB              1552 	sjmp	00135$
   056C                    1553 00138$:
                           1554 ;	gamelogic.c:271: matrixData[0] = 0;
   056C 75 23 00           1555 	mov	_matrixData,#0x00
                           1556 ;	gamelogic.c:272: score++;
   056F 05 41              1557 	inc	_score
   0571                    1558 00118$:
                           1559 ;	gamelogic.c:276: posX = 3;
   0571 75 34 03           1560 	mov	_posX,#0x03
                           1561 ;	gamelogic.c:277: posY = 0;
   0574 75 35 00           1562 	mov	_posY,#0x00
   0577                    1563 00121$:
                           1564 ;	gamelogic.c:281: if(matrixColPut(1, posX, posY)) return gameOver();
   0577 85 34 08           1565 	mov	_matrixColPut_PARM_2,_posX
   057A 75 09 00           1566 	mov	(_matrixColPut_PARM_2 + 1),#0x00
   057D 85 35 0A           1567 	mov	_matrixColPut_PARM_3,_posY
   0580 75 0B 00           1568 	mov	(_matrixColPut_PARM_3 + 1),#0x00
   0583 75 82 01           1569 	mov	dpl,#0x01
   0586 12 02 28           1570 	lcall	_matrixColPut
   0589 E5 82              1571 	mov	a,dpl
   058B 60 03              1572 	jz	00126$
   058D 02 02 D4           1573 	ljmp	_gameOver
   0590                    1574 00126$:
                           1575 ;	gamelogic.c:285: if(loop%10 == 0){
   0590 75 08 0A           1576 	mov	__moduint_PARM_2,#0x0A
   0593 75 09 00           1577 	mov	(__moduint_PARM_2 + 1),#0x00
   0596 85 3F 82           1578 	mov	dpl,_loop
   0599 85 40 83           1579 	mov	dph,(_loop + 1)
   059C 12 0A D6           1580 	lcall	__moduint
   059F E5 82              1581 	mov	a,dpl
   05A1 85 83 F0           1582 	mov	b,dph
   05A4 45 F0              1583 	orl	a,b
   05A6 70 57              1584 	jnz	00139$
                           1585 ;	gamelogic.c:286: if(timing[currentNote] == ' '){
   05A8 E5 46              1586 	mov	a,_currentNote
   05AA 90 0B 9C           1587 	mov	dptr,#_timing
   05AD 93                 1588 	movc	a,@a+dptr
   05AE FF                 1589 	mov	r7,a
   05AF BF 20 0E           1590 	cjne	r7,#0x20,00128$
                           1591 ;	gamelogic.c:287: soundStop();
   05B2 12 02 A5           1592 	lcall	_soundStop
                           1593 ;	gamelogic.c:288: currentNote++;
   05B5 05 46              1594 	inc	_currentNote
                           1595 ;	gamelogic.c:289: currentNote%=78;									
   05B7 75 F0 4E           1596 	mov	b,#0x4E
   05BA E5 46              1597 	mov	a,_currentNote
   05BC 84                 1598 	div	ab
   05BD 85 F0 46           1599 	mov	_currentNote,b
   05C0                    1600 00128$:
                           1601 ;	gamelogic.c:291: if(song[currentNote] != ' ')
   05C0 E5 46              1602 	mov	a,_currentNote
   05C2 90 0B 4D           1603 	mov	dptr,#_song
   05C5 93                 1604 	movc	a,@a+dptr
   05C6 FF                 1605 	mov	r7,a
   05C7 BF 20 02           1606 	cjne	r7,#0x20,00199$
   05CA 80 08              1607 	sjmp	00130$
   05CC                    1608 00199$:
                           1609 ;	gamelogic.c:292: soundPlay(song[currentNote]-'A');
   05CC EF                 1610 	mov	a,r7
   05CD 24 BF              1611 	add	a,#0xBF
   05CF F5 82              1612 	mov	dpl,a
   05D1 12 02 AA           1613 	lcall	_soundPlay
   05D4                    1614 00130$:
                           1615 ;	gamelogic.c:293: currentTiming++;
   05D4 05 47              1616 	inc	_currentTiming
                           1617 ;	gamelogic.c:295: if(currentTiming == timing[currentNote]-'0'){
   05D6 E5 46              1618 	mov	a,_currentNote
   05D8 90 0B 9C           1619 	mov	dptr,#_timing
   05DB 93                 1620 	movc	a,@a+dptr
   05DC 7E 00              1621 	mov	r6,#0x00
   05DE 24 D0              1622 	add	a,#0xD0
   05E0 FF                 1623 	mov	r7,a
   05E1 EE                 1624 	mov	a,r6
   05E2 34 FF              1625 	addc	a,#0xFF
   05E4 FE                 1626 	mov	r6,a
   05E5 AC 47              1627 	mov	r4,_currentTiming
   05E7 7D 00              1628 	mov	r5,#0x00
   05E9 EC                 1629 	mov	a,r4
   05EA B5 07 12           1630 	cjne	a,ar7,00139$
   05ED ED                 1631 	mov	a,r5
   05EE B5 06 0E           1632 	cjne	a,ar6,00139$
                           1633 ;	gamelogic.c:296: currentTiming = 0;
   05F1 75 47 00           1634 	mov	_currentTiming,#0x00
                           1635 ;	gamelogic.c:297: currentNote++;
   05F4 05 46              1636 	inc	_currentNote
                           1637 ;	gamelogic.c:298: currentNote%=78;					
   05F6 75 F0 4E           1638 	mov	b,#0x4E
   05F9 E5 46              1639 	mov	a,_currentNote
   05FB 84                 1640 	div	ab
   05FC 85 F0 46           1641 	mov	_currentNote,b
   05FF                    1642 00139$:
   05FF 22                 1643 	ret
                           1644 ;------------------------------------------------------------
                           1645 ;Allocation info for local variables in function 'gameCar'
                           1646 ;------------------------------------------------------------
                           1647 ;i                         Allocated to registers r7 
                           1648 ;------------------------------------------------------------
                           1649 ;	gamelogic.c:303: void gameCar()
                           1650 ;	-----------------------------------------
                           1651 ;	 function gameCar
                           1652 ;	-----------------------------------------
   0600                    1653 _gameCar:
                           1654 ;	gamelogic.c:307: matrixClr(posX, posY);
   0600 85 35 08           1655 	mov	_matrixClr_PARM_2,_posY
   0603 85 34 82           1656 	mov	dpl,_posX
   0606 12 01 CF           1657 	lcall	_matrixClr
                           1658 ;	gamelogic.c:309: if(BTN_LEFT)
   0609 20 B5 12           1659 	jb	_P3_5,00106$
                           1660 ;	gamelogic.c:311: if(buttonLeft == 0)
   060C E5 44              1661 	mov	a,_buttonLeft
   060E 70 11              1662 	jnz	00107$
                           1663 ;	gamelogic.c:313: randomNumber = TL1;
   0610 85 8B 38           1664 	mov	_randomNumber,_TL1
                           1665 ;	gamelogic.c:314: buttonLeft = 1;
   0613 75 44 01           1666 	mov	_buttonLeft,#0x01
                           1667 ;	gamelogic.c:315: if(posX!=0) posX--;
   0616 E5 34              1668 	mov	a,_posX
   0618 60 07              1669 	jz	00107$
   061A 15 34              1670 	dec	_posX
   061C 80 03              1671 	sjmp	00107$
   061E                    1672 00106$:
                           1673 ;	gamelogic.c:319: buttonLeft = 0;
   061E 75 44 00           1674 	mov	_buttonLeft,#0x00
   0621                    1675 00107$:
                           1676 ;	gamelogic.c:321: if(BTN_RIGHT)
   0621 20 B3 15           1677 	jb	_P3_3,00113$
                           1678 ;	gamelogic.c:323: if(buttonRight == 0)
   0624 E5 45              1679 	mov	a,_buttonRight
   0626 70 14              1680 	jnz	00114$
                           1681 ;	gamelogic.c:325: randomNumber = TL1;
   0628 85 8B 38           1682 	mov	_randomNumber,_TL1
                           1683 ;	gamelogic.c:326: buttonRight = 1;
   062B 75 45 01           1684 	mov	_buttonRight,#0x01
                           1685 ;	gamelogic.c:327: if(posX!=7) posX++;
   062E 74 07              1686 	mov	a,#0x07
   0630 B5 34 02           1687 	cjne	a,_posX,00171$
   0633 80 07              1688 	sjmp	00114$
   0635                    1689 00171$:
   0635 05 34              1690 	inc	_posX
   0637 80 03              1691 	sjmp	00114$
   0639                    1692 00113$:
                           1693 ;	gamelogic.c:331: buttonRight = 0;
   0639 75 45 00           1694 	mov	_buttonRight,#0x00
   063C                    1695 00114$:
                           1696 ;	gamelogic.c:335: matrixSet(posX, posY);
   063C 85 35 08           1697 	mov	_matrixSet_PARM_2,_posY
   063F 85 34 82           1698 	mov	dpl,_posX
   0642 12 01 B2           1699 	lcall	_matrixSet
                           1700 ;	gamelogic.c:337: matrixIntensity[7] = 1<<(7-posX);	
   0645 74 07              1701 	mov	a,#0x07
   0647 C3                 1702 	clr	c
   0648 95 34              1703 	subb	a,_posX
   064A F5 F0              1704 	mov	b,a
   064C 05 F0              1705 	inc	b
   064E 74 01              1706 	mov	a,#0x01
   0650 80 02              1707 	sjmp	00174$
   0652                    1708 00172$:
   0652 25 E0              1709 	add	a,acc
   0654                    1710 00174$:
   0654 D5 F0 FB           1711 	djnz	b,00172$
   0657 F5 32              1712 	mov	(_matrixIntensity + 0x0007),a
                           1713 ;	gamelogic.c:339: if(loop%10 == 0)
   0659 75 08 0A           1714 	mov	__moduint_PARM_2,#0x0A
   065C 75 09 00           1715 	mov	(__moduint_PARM_2 + 1),#0x00
   065F 85 3F 82           1716 	mov	dpl,_loop
   0662 85 40 83           1717 	mov	dph,(_loop + 1)
   0665 12 0A D6           1718 	lcall	__moduint
   0668 E5 82              1719 	mov	a,dpl
   066A 85 83 F0           1720 	mov	b,dph
   066D 45 F0              1721 	orl	a,b
   066F 70 6D              1722 	jnz	00127$
                           1723 ;	gamelogic.c:344: for(i=7;i>0;i--) matrixData[i] = matrixData[i-1];
   0671 7F 07              1724 	mov	r7,#0x07
   0673                    1725 00130$:
   0673 EF                 1726 	mov	a,r7
   0674 60 12              1727 	jz	00133$
   0676 EF                 1728 	mov	a,r7
   0677 24 23              1729 	add	a,#_matrixData
   0679 F9                 1730 	mov	r1,a
   067A EF                 1731 	mov	a,r7
   067B 14                 1732 	dec	a
   067C FE                 1733 	mov	r6,a
   067D 24 23              1734 	add	a,#_matrixData
   067F F8                 1735 	mov	r0,a
   0680 86 05              1736 	mov	ar5,@r0
   0682 A7 05              1737 	mov	@r1,ar5
   0684 8E 07              1738 	mov	ar7,r6
   0686 80 EB              1739 	sjmp	00130$
   0688                    1740 00133$:
                           1741 ;	gamelogic.c:347: if(matrixColPut(1, posX, posY)) return gameOver();		
   0688 85 34 08           1742 	mov	_matrixColPut_PARM_2,_posX
   068B 75 09 00           1743 	mov	(_matrixColPut_PARM_2 + 1),#0x00
   068E 85 35 0A           1744 	mov	_matrixColPut_PARM_3,_posY
   0691 75 0B 00           1745 	mov	(_matrixColPut_PARM_3 + 1),#0x00
   0694 75 82 01           1746 	mov	dpl,#0x01
   0697 12 02 28           1747 	lcall	_matrixColPut
   069A E5 82              1748 	mov	a,dpl
   069C 60 03              1749 	jz	00116$
   069E 02 02 D4           1750 	ljmp	_gameOver
   06A1                    1751 00116$:
                           1752 ;	gamelogic.c:350: if(!(matrixData[1] & 0x80))
   06A1 E5 24              1753 	mov	a,(_matrixData + 0x0001)
   06A3 FF                 1754 	mov	r7,a
   06A4 20 E7 0B           1755 	jb	acc.7,00124$
                           1756 ;	gamelogic.c:353: matrixData[0] = (matrixData[1] >> 1) | 0x80; 			
   06A7 EF                 1757 	mov	a,r7
   06A8 C3                 1758 	clr	c
   06A9 13                 1759 	rrc	a
   06AA FE                 1760 	mov	r6,a
   06AB 74 80              1761 	mov	a,#0x80
   06AD 4E                 1762 	orl	a,r6
   06AE F5 23              1763 	mov	_matrixData,a
   06B0 80 2C              1764 	sjmp	00127$
   06B2                    1765 00124$:
                           1766 ;	gamelogic.c:358: if(!(matrixData[1] & 0x01))
   06B2 EF                 1767 	mov	a,r7
   06B3 20 E0 0A           1768 	jb	acc.0,00121$
                           1769 ;	gamelogic.c:361: matrixData[0] = (matrixData[1] << 1) | 1; 			
   06B6 EF                 1770 	mov	a,r7
   06B7 2F                 1771 	add	a,r7
   06B8 FF                 1772 	mov	r7,a
   06B9 74 01              1773 	mov	a,#0x01
   06BB 4F                 1774 	orl	a,r7
   06BC F5 23              1775 	mov	_matrixData,a
   06BE 80 1E              1776 	sjmp	00127$
   06C0                    1777 00121$:
                           1778 ;	gamelogic.c:367: if(getRandomNumber()&0x80)
   06C0 12 02 C6           1779 	lcall	_getRandomNumber
   06C3 E5 82              1780 	mov	a,dpl
   06C5 30 E7 0C           1781 	jnb	acc.7,00118$
                           1782 ;	gamelogic.c:369: matrixData[0] = (matrixData[1] << 1) | 1; 			
   06C8 E5 24              1783 	mov	a,(_matrixData + 0x0001)
   06CA 25 E0              1784 	add	a,acc
   06CC FF                 1785 	mov	r7,a
   06CD 74 01              1786 	mov	a,#0x01
   06CF 4F                 1787 	orl	a,r7
   06D0 F5 23              1788 	mov	_matrixData,a
   06D2 80 0A              1789 	sjmp	00127$
   06D4                    1790 00118$:
                           1791 ;	gamelogic.c:373: matrixData[0] = (matrixData[1] >> 1) | 0x80; 
   06D4 E5 24              1792 	mov	a,(_matrixData + 0x0001)
   06D6 C3                 1793 	clr	c
   06D7 13                 1794 	rrc	a
   06D8 FF                 1795 	mov	r7,a
   06D9 74 80              1796 	mov	a,#0x80
   06DB 4F                 1797 	orl	a,r7
   06DC F5 23              1798 	mov	_matrixData,a
   06DE                    1799 00127$:
                           1800 ;	gamelogic.c:379: if(loop%80==0)
   06DE 75 08 50           1801 	mov	__moduint_PARM_2,#0x50
   06E1 75 09 00           1802 	mov	(__moduint_PARM_2 + 1),#0x00
   06E4 85 3F 82           1803 	mov	dpl,_loop
   06E7 85 40 83           1804 	mov	dph,(_loop + 1)
   06EA 12 0A D6           1805 	lcall	__moduint
   06ED E5 82              1806 	mov	a,dpl
   06EF 85 83 F0           1807 	mov	b,dph
   06F2 45 F0              1808 	orl	a,b
   06F4 70 02              1809 	jnz	00134$
                           1810 ;	gamelogic.c:382: score++;
   06F6 05 41              1811 	inc	_score
   06F8                    1812 00134$:
   06F8 22                 1813 	ret
                           1814 ;------------------------------------------------------------
                           1815 ;Allocation info for local variables in function 'gameChopper'
                           1816 ;------------------------------------------------------------
                           1817 ;i                         Allocated to registers r7 
                           1818 ;------------------------------------------------------------
                           1819 ;	gamelogic.c:386: void gameChopper()
                           1820 ;	-----------------------------------------
                           1821 ;	 function gameChopper
                           1822 ;	-----------------------------------------
   06F9                    1823 _gameChopper:
                           1824 ;	gamelogic.c:389: if(loop%5 == 0)
   06F9 75 08 05           1825 	mov	__moduint_PARM_2,#0x05
   06FC 75 09 00           1826 	mov	(__moduint_PARM_2 + 1),#0x00
   06FF 85 3F 82           1827 	mov	dpl,_loop
   0702 85 40 83           1828 	mov	dph,(_loop + 1)
   0705 12 0A D6           1829 	lcall	__moduint
   0708 E5 82              1830 	mov	a,dpl
   070A 85 83 F0           1831 	mov	b,dph
   070D 45 F0              1832 	orl	a,b
   070F 70 5D              1833 	jnz	00122$
                           1834 ;	gamelogic.c:393: matrixClr(posX,posY);
   0711 85 35 08           1835 	mov	_matrixClr_PARM_2,_posY
   0714 85 34 82           1836 	mov	dpl,_posX
   0717 12 01 CF           1837 	lcall	_matrixClr
                           1838 ;	gamelogic.c:394: if(BTN_UP || BTN_DOWN || BTN_LEFT || BTN_RIGHT) randomNumber = TL1;
   071A 30 B4 09           1839 	jnb	_P3_4,00101$
   071D 30 B2 06           1840 	jnb	_P3_2,00101$
   0720 30 B5 03           1841 	jnb	_P3_5,00101$
   0723 20 B3 03           1842 	jb	_P3_3,00102$
   0726                    1843 00101$:
   0726 85 8B 38           1844 	mov	_randomNumber,_TL1
   0729                    1845 00102$:
                           1846 ;	gamelogic.c:395: if(BTN_UP && posY!=0)posY--;
   0729 20 B4 06           1847 	jb	_P3_4,00107$
   072C E5 35              1848 	mov	a,_posY
   072E 60 02              1849 	jz	00107$
   0730 15 35              1850 	dec	_posY
   0732                    1851 00107$:
                           1852 ;	gamelogic.c:396: if(BTN_DOWN)posY++;
   0732 20 B2 02           1853 	jb	_P3_2,00110$
   0735 05 35              1854 	inc	_posY
   0737                    1855 00110$:
                           1856 ;	gamelogic.c:397: if(BTN_LEFT && posX!=0)posX--;
   0737 20 B5 06           1857 	jb	_P3_5,00112$
   073A E5 34              1858 	mov	a,_posX
   073C 60 02              1859 	jz	00112$
   073E 15 34              1860 	dec	_posX
   0740                    1861 00112$:
                           1862 ;	gamelogic.c:398: if(BTN_RIGHT && posX!=7)posX++;
   0740 20 B3 09           1863 	jb	_P3_3,00115$
   0743 74 07              1864 	mov	a,#0x07
   0745 B5 34 02           1865 	cjne	a,_posX,00193$
   0748 80 02              1866 	sjmp	00115$
   074A                    1867 00193$:
   074A 05 34              1868 	inc	_posX
   074C                    1869 00115$:
                           1870 ;	gamelogic.c:399: if(posY>7) return gameOver();
   074C E5 35              1871 	mov	a,_posY
   074E 24 F8              1872 	add	a,#0xff - 0x07
   0750 50 03              1873 	jnc	00118$
   0752 02 02 D4           1874 	ljmp	_gameOver
   0755                    1875 00118$:
                           1876 ;	gamelogic.c:400: if(matrixColPut(1,posX,posY)) return gameOver();
   0755 85 34 08           1877 	mov	_matrixColPut_PARM_2,_posX
   0758 75 09 00           1878 	mov	(_matrixColPut_PARM_2 + 1),#0x00
   075B 85 35 0A           1879 	mov	_matrixColPut_PARM_3,_posY
   075E 75 0B 00           1880 	mov	(_matrixColPut_PARM_3 + 1),#0x00
   0761 75 82 01           1881 	mov	dpl,#0x01
   0764 12 02 28           1882 	lcall	_matrixColPut
   0767 E5 82              1883 	mov	a,dpl
   0769 60 03              1884 	jz	00122$
   076B 02 02 D4           1885 	ljmp	_gameOver
   076E                    1886 00122$:
                           1887 ;	gamelogic.c:402: if(loop%15 == 0)
   076E 75 08 0F           1888 	mov	__moduint_PARM_2,#0x0F
   0771 75 09 00           1889 	mov	(__moduint_PARM_2 + 1),#0x00
   0774 85 3F 82           1890 	mov	dpl,_loop
   0777 85 40 83           1891 	mov	dph,(_loop + 1)
   077A 12 0A D6           1892 	lcall	__moduint
   077D E5 82              1893 	mov	a,dpl
   077F 85 83 F0           1894 	mov	b,dph
   0782 45 F0              1895 	orl	a,b
   0784 60 01              1896 	jz	00196$
   0786 22                 1897 	ret
   0787                    1898 00196$:
                           1899 ;	gamelogic.c:405: for(i=0;i<8;i++) matrixData[i] <<=1;
   0787 7F 00              1900 	mov	r7,#0x00
   0789                    1901 00137$:
   0789 BF 08 00           1902 	cjne	r7,#0x08,00197$
   078C                    1903 00197$:
   078C 50 0B              1904 	jnc	00140$
   078E EF                 1905 	mov	a,r7
   078F 24 23              1906 	add	a,#_matrixData
   0791 F9                 1907 	mov	r1,a
   0792 E7                 1908 	mov	a,@r1
   0793 27                 1909 	add	a,@r1
   0794 FE                 1910 	mov	r6,a
   0795 F7                 1911 	mov	@r1,a
   0796 0F                 1912 	inc	r7
   0797 80 F0              1913 	sjmp	00137$
   0799                    1914 00140$:
                           1915 ;	gamelogic.c:409: switch(getRandomNumber()%10)
   0799 12 02 C6           1916 	lcall	_getRandomNumber
   079C E5 82              1917 	mov	a,dpl
   079E 75 F0 0A           1918 	mov	b,#0x0A
   07A1 84                 1919 	div	ab
   07A2 E5 F0              1920 	mov	a,b
   07A4 FF                 1921 	mov	r7,a
   07A5 24 FA              1922 	add	a,#0xff - 0x05
   07A7 40 6B              1923 	jc	00130$
   07A9 EF                 1924 	mov	a,r7
   07AA 2F                 1925 	add	a,r7
   07AB 2F                 1926 	add	a,r7
   07AC 90 07 B0           1927 	mov	dptr,#00200$
   07AF 73                 1928 	jmp	@a+dptr
   07B0                    1929 00200$:
   07B0 02 07 C2           1930 	ljmp	00123$
   07B3 02 07 D0           1931 	ljmp	00124$
   07B6 02 07 DE           1932 	ljmp	00125$
   07B9 02 07 EC           1933 	ljmp	00126$
   07BC 02 07 FA           1934 	ljmp	00127$
   07BF 02 08 08           1935 	ljmp	00128$
                           1936 ;	gamelogic.c:411: case 0:
   07C2                    1937 00123$:
                           1938 ;	gamelogic.c:412: matrixData[3] |=1;
   07C2 74 01              1939 	mov	a,#0x01
   07C4 45 26              1940 	orl	a,(_matrixData + 0x0003)
   07C6 F5 26              1941 	mov	(_matrixData + 0x0003),a
                           1942 ;	gamelogic.c:413: matrixData[4] |=1;
   07C8 74 01              1943 	mov	a,#0x01
   07CA 45 27              1944 	orl	a,(_matrixData + 0x0004)
   07CC F5 27              1945 	mov	(_matrixData + 0x0004),a
                           1946 ;	gamelogic.c:414: break;
                           1947 ;	gamelogic.c:415: case 1:
   07CE 80 44              1948 	sjmp	00130$
   07D0                    1949 00124$:
                           1950 ;	gamelogic.c:416: matrixData[4] |=1;
   07D0 74 01              1951 	mov	a,#0x01
   07D2 45 27              1952 	orl	a,(_matrixData + 0x0004)
   07D4 F5 27              1953 	mov	(_matrixData + 0x0004),a
                           1954 ;	gamelogic.c:417: matrixData[5] |=1;
   07D6 74 01              1955 	mov	a,#0x01
   07D8 45 28              1956 	orl	a,(_matrixData + 0x0005)
   07DA F5 28              1957 	mov	(_matrixData + 0x0005),a
                           1958 ;	gamelogic.c:418: break;
                           1959 ;	gamelogic.c:419: case 2:
   07DC 80 36              1960 	sjmp	00130$
   07DE                    1961 00125$:
                           1962 ;	gamelogic.c:420: matrixData[1] |=1;
   07DE 74 01              1963 	mov	a,#0x01
   07E0 45 24              1964 	orl	a,(_matrixData + 0x0001)
   07E2 F5 24              1965 	mov	(_matrixData + 0x0001),a
                           1966 ;	gamelogic.c:421: matrixData[2] |=1;
   07E4 74 01              1967 	mov	a,#0x01
   07E6 45 25              1968 	orl	a,(_matrixData + 0x0002)
   07E8 F5 25              1969 	mov	(_matrixData + 0x0002),a
                           1970 ;	gamelogic.c:422: break;
                           1971 ;	gamelogic.c:423: case 3:
   07EA 80 28              1972 	sjmp	00130$
   07EC                    1973 00126$:
                           1974 ;	gamelogic.c:424: matrixData[1] |=1;
   07EC 74 01              1975 	mov	a,#0x01
   07EE 45 24              1976 	orl	a,(_matrixData + 0x0001)
   07F0 F5 24              1977 	mov	(_matrixData + 0x0001),a
                           1978 ;	gamelogic.c:425: matrixData[3] |=1;
   07F2 74 01              1979 	mov	a,#0x01
   07F4 45 26              1980 	orl	a,(_matrixData + 0x0003)
   07F6 F5 26              1981 	mov	(_matrixData + 0x0003),a
                           1982 ;	gamelogic.c:426: break;
                           1983 ;	gamelogic.c:427: case 4:
   07F8 80 1A              1984 	sjmp	00130$
   07FA                    1985 00127$:
                           1986 ;	gamelogic.c:428: matrixData[0] |=1;
   07FA 74 01              1987 	mov	a,#0x01
   07FC 45 23              1988 	orl	a,_matrixData
   07FE F5 23              1989 	mov	_matrixData,a
                           1990 ;	gamelogic.c:429: matrixData[4] |=1;
   0800 74 01              1991 	mov	a,#0x01
   0802 45 27              1992 	orl	a,(_matrixData + 0x0004)
   0804 F5 27              1993 	mov	(_matrixData + 0x0004),a
                           1994 ;	gamelogic.c:430: break;
                           1995 ;	gamelogic.c:431: case 5:
   0806 80 0C              1996 	sjmp	00130$
   0808                    1997 00128$:
                           1998 ;	gamelogic.c:432: matrixData[6] |=1;
   0808 74 01              1999 	mov	a,#0x01
   080A 45 29              2000 	orl	a,(_matrixData + 0x0006)
   080C F5 29              2001 	mov	(_matrixData + 0x0006),a
                           2002 ;	gamelogic.c:433: matrixData[5] |=1;
   080E 74 01              2003 	mov	a,#0x01
   0810 45 28              2004 	orl	a,(_matrixData + 0x0005)
   0812 F5 28              2005 	mov	(_matrixData + 0x0005),a
                           2006 ;	gamelogic.c:437: }
   0814                    2007 00130$:
                           2008 ;	gamelogic.c:440: matrixData[7] = 0xFF;
   0814 75 2A FF           2009 	mov	(_matrixData + 0x0007),#0xFF
                           2010 ;	gamelogic.c:444: matrixClr(posX-1,posY);
   0817 E5 34              2011 	mov	a,_posX
   0819 14                 2012 	dec	a
   081A F5 82              2013 	mov	dpl,a
   081C 85 35 08           2014 	mov	_matrixClr_PARM_2,_posY
   081F 12 01 CF           2015 	lcall	_matrixClr
                           2016 ;	gamelogic.c:447: if(matrixColPut(1,posX,posY)) return gameOver();				
   0822 85 34 08           2017 	mov	_matrixColPut_PARM_2,_posX
   0825 75 09 00           2018 	mov	(_matrixColPut_PARM_2 + 1),#0x00
   0828 85 35 0A           2019 	mov	_matrixColPut_PARM_3,_posY
   082B 75 0B 00           2020 	mov	(_matrixColPut_PARM_3 + 1),#0x00
   082E 75 82 01           2021 	mov	dpl,#0x01
   0831 12 02 28           2022 	lcall	_matrixColPut
   0834 E5 82              2023 	mov	a,dpl
   0836 60 03              2024 	jz	00132$
   0838 02 02 D4           2025 	ljmp	_gameOver
   083B                    2026 00132$:
                           2027 ;	gamelogic.c:449: if(loop%120==0)
   083B 75 08 78           2028 	mov	__moduint_PARM_2,#0x78
   083E 75 09 00           2029 	mov	(__moduint_PARM_2 + 1),#0x00
   0841 85 3F 82           2030 	mov	dpl,_loop
   0844 85 40 83           2031 	mov	dph,(_loop + 1)
   0847 12 0A D6           2032 	lcall	__moduint
   084A E5 82              2033 	mov	a,dpl
   084C 85 83 F0           2034 	mov	b,dph
   084F 45 F0              2035 	orl	a,b
   0851 70 02              2036 	jnz	00141$
                           2037 ;	gamelogic.c:452: score++;
   0853 05 41              2038 	inc	_score
   0855                    2039 00141$:
   0855 22                 2040 	ret
                           2041 ;------------------------------------------------------------
                           2042 ;Allocation info for local variables in function 'gameSnake'
                           2043 ;------------------------------------------------------------
                           2044 ;i                         Allocated to registers r7 
                           2045 ;------------------------------------------------------------
                           2046 ;	gamelogic.c:457: void gameSnake()
                           2047 ;	-----------------------------------------
                           2048 ;	 function gameSnake
                           2049 ;	-----------------------------------------
   0856                    2050 _gameSnake:
                           2051 ;	gamelogic.c:460: if(keyAffects==1){
   0856 74 01              2052 	mov	a,#0x01
   0858 B5 3C 3E           2053 	cjne	a,_keyAffects,00118$
                           2054 ;	gamelogic.c:461: keyAffects=0;
   085B 75 3C 00           2055 	mov	_keyAffects,#0x00
                           2056 ;	gamelogic.c:462: if(BTN_LEFT && vX==0)
   085E 20 B5 0B           2057 	jb	_P3_5,00114$
   0861 E5 3D              2058 	mov	a,_vX
                           2059 ;	gamelogic.c:464: vX=-1;
                           2060 ;	gamelogic.c:465: vY=0;
   0863 70 07              2061 	jnz	00114$
   0865 75 3D FF           2062 	mov	_vX,#0xFF
   0868 F5 3E              2063 	mov	_vY,a
   086A 80 2D              2064 	sjmp	00118$
   086C                    2065 00114$:
                           2066 ;	gamelogic.c:466: }else if(BTN_RIGHT && vX==0)
   086C 20 B3 0B           2067 	jb	_P3_3,00110$
   086F E5 3D              2068 	mov	a,_vX
                           2069 ;	gamelogic.c:468: vX=1;
                           2070 ;	gamelogic.c:469: vY=0;
   0871 70 07              2071 	jnz	00110$
   0873 75 3D 01           2072 	mov	_vX,#0x01
   0876 F5 3E              2073 	mov	_vY,a
   0878 80 1F              2074 	sjmp	00118$
   087A                    2075 00110$:
                           2076 ;	gamelogic.c:470: }else if(BTN_UP && vY == 0)
   087A 20 B4 0B           2077 	jb	_P3_4,00106$
   087D E5 3E              2078 	mov	a,_vY
                           2079 ;	gamelogic.c:472: vX=0;
   087F 70 07              2080 	jnz	00106$
   0881 F5 3D              2081 	mov	_vX,a
                           2082 ;	gamelogic.c:473: vY=-1;
   0883 75 3E FF           2083 	mov	_vY,#0xFF
   0886 80 11              2084 	sjmp	00118$
   0888                    2085 00106$:
                           2086 ;	gamelogic.c:474: }else if(BTN_DOWN && vY == 0)
   0888 20 B2 0B           2087 	jb	_P3_2,00102$
   088B E5 3E              2088 	mov	a,_vY
                           2089 ;	gamelogic.c:476: vX=0;
   088D 70 07              2090 	jnz	00102$
   088F F5 3D              2091 	mov	_vX,a
                           2092 ;	gamelogic.c:477: vY=1;
   0891 75 3E 01           2093 	mov	_vY,#0x01
   0894 80 03              2094 	sjmp	00118$
   0896                    2095 00102$:
                           2096 ;	gamelogic.c:479: keyAffects=1;
   0896 75 3C 01           2097 	mov	_keyAffects,#0x01
   0899                    2098 00118$:
                           2099 ;	gamelogic.c:482: if(loop%10 == 0)
   0899 75 08 0A           2100 	mov	__moduint_PARM_2,#0x0A
   089C 75 09 00           2101 	mov	(__moduint_PARM_2 + 1),#0x00
   089F 85 3F 82           2102 	mov	dpl,_loop
   08A2 85 40 83           2103 	mov	dph,(_loop + 1)
   08A5 12 0A D6           2104 	lcall	__moduint
   08A8 E5 82              2105 	mov	a,dpl
   08AA 85 83 F0           2106 	mov	b,dph
   08AD 45 F0              2107 	orl	a,b
   08AF 60 01              2108 	jz	00203$
   08B1 22                 2109 	ret
   08B2                    2110 00203$:
                           2111 ;	gamelogic.c:484: keyAffects = 1;
   08B2 75 3C 01           2112 	mov	_keyAffects,#0x01
                           2113 ;	gamelogic.c:486: matrixCls();
   08B5 12 01 1D           2114 	lcall	_matrixCls
                           2115 ;	gamelogic.c:488: matrixSet(fruitX, fruitY);
   08B8 85 3A 08           2116 	mov	_matrixSet_PARM_2,_fruitY
   08BB 85 39 82           2117 	mov	dpl,_fruitX
   08BE 12 01 B2           2118 	lcall	_matrixSet
                           2119 ;	gamelogic.c:490: for(i=snakeLen;i>=1;i--){
   08C1 AF 3B              2120 	mov	r7,_snakeLen
   08C3                    2121 00138$:
   08C3 C3                 2122 	clr	c
   08C4 EF                 2123 	mov	a,r7
   08C5 64 80              2124 	xrl	a,#0x80
   08C7 94 81              2125 	subb	a,#0x81
   08C9 40 1E              2126 	jc	00141$
                           2127 ;	gamelogic.c:491: snakePosX[i] = snakePosX[i-1];
   08CB EF                 2128 	mov	a,r7
   08CC 24 80              2129 	add	a,#_snakePosX
   08CE F9                 2130 	mov	r1,a
   08CF EF                 2131 	mov	a,r7
   08D0 14                 2132 	dec	a
   08D1 FE                 2133 	mov	r6,a
   08D2 24 80              2134 	add	a,#_snakePosX
   08D4 F8                 2135 	mov	r0,a
   08D5 86 05              2136 	mov	ar5,@r0
   08D7 A7 05              2137 	mov	@r1,ar5
                           2138 ;	gamelogic.c:492: snakePosY[i] = snakePosY[i-1];				
   08D9 EF                 2139 	mov	a,r7
   08DA 24 C0              2140 	add	a,#_snakePosY
   08DC F9                 2141 	mov	r1,a
   08DD EE                 2142 	mov	a,r6
   08DE 24 C0              2143 	add	a,#_snakePosY
   08E0 F8                 2144 	mov	r0,a
   08E1 86 05              2145 	mov	ar5,@r0
   08E3 A7 05              2146 	mov	@r1,ar5
                           2147 ;	gamelogic.c:490: for(i=snakeLen;i>=1;i--){
   08E5 8E 07              2148 	mov	ar7,r6
   08E7 80 DA              2149 	sjmp	00138$
   08E9                    2150 00141$:
                           2151 ;	gamelogic.c:495: snakePosX[0]+=vX;
   08E9 78 80              2152 	mov	r0,#_snakePosX
   08EB 86 07              2153 	mov	ar7,@r0
   08ED E5 3D              2154 	mov	a,_vX
   08EF 2F                 2155 	add	a,r7
   08F0 78 80              2156 	mov	r0,#_snakePosX
   08F2 F6                 2157 	mov	@r0,a
                           2158 ;	gamelogic.c:496: snakePosY[0]+=vY;
   08F3 78 C0              2159 	mov	r0,#_snakePosY
   08F5 86 07              2160 	mov	ar7,@r0
   08F7 E5 3E              2161 	mov	a,_vY
   08F9 2F                 2162 	add	a,r7
   08FA 78 C0              2163 	mov	r0,#_snakePosY
   08FC F6                 2164 	mov	@r0,a
                           2165 ;	gamelogic.c:498: if(snakePosX[0]==8) snakePosX[0] = 0;
   08FD 78 80              2166 	mov	r0,#_snakePosX
   08FF 86 07              2167 	mov	ar7,@r0
   0901 BF 08 04           2168 	cjne	r7,#0x08,00120$
   0904 78 80              2169 	mov	r0,#_snakePosX
   0906 76 00              2170 	mov	@r0,#0x00
   0908                    2171 00120$:
                           2172 ;	gamelogic.c:499: if(snakePosX[0]==0xFF) snakePosX[0] = 7;
   0908 78 80              2173 	mov	r0,#_snakePosX
   090A 86 07              2174 	mov	ar7,@r0
   090C BF FF 04           2175 	cjne	r7,#0xFF,00122$
   090F 78 80              2176 	mov	r0,#_snakePosX
   0911 76 07              2177 	mov	@r0,#0x07
   0913                    2178 00122$:
                           2179 ;	gamelogic.c:501: if(snakePosY[0]==8) snakePosY[0] = 0;
   0913 78 C0              2180 	mov	r0,#_snakePosY
   0915 86 07              2181 	mov	ar7,@r0
   0917 BF 08 04           2182 	cjne	r7,#0x08,00124$
   091A 78 C0              2183 	mov	r0,#_snakePosY
   091C 76 00              2184 	mov	@r0,#0x00
   091E                    2185 00124$:
                           2186 ;	gamelogic.c:502: if(snakePosY[0]==0xFF) snakePosY[0] = 7;
   091E 78 C0              2187 	mov	r0,#_snakePosY
   0920 86 07              2188 	mov	ar7,@r0
   0922 BF FF 04           2189 	cjne	r7,#0xFF,00165$
   0925 78 C0              2190 	mov	r0,#_snakePosY
   0927 76 07              2191 	mov	@r0,#0x07
                           2192 ;	gamelogic.c:504: for(i=1;i<snakeLen;i++)
   0929                    2193 00165$:
   0929 7F 01              2194 	mov	r7,#0x01
   092B                    2195 00142$:
   092B EF                 2196 	mov	a,r7
   092C FD                 2197 	mov	r5,a
   092D 33                 2198 	rlc	a
   092E 95 E0              2199 	subb	a,acc
   0930 FE                 2200 	mov	r6,a
   0931 AB 3B              2201 	mov	r3,_snakeLen
   0933 7C 00              2202 	mov	r4,#0x00
   0935 C3                 2203 	clr	c
   0936 ED                 2204 	mov	a,r5
   0937 9B                 2205 	subb	a,r3
   0938 EE                 2206 	mov	a,r6
   0939 64 80              2207 	xrl	a,#0x80
   093B 8C F0              2208 	mov	b,r4
   093D 63 F0 80           2209 	xrl	b,#0x80
   0940 95 F0              2210 	subb	a,b
   0942 50 16              2211 	jnc	00145$
                           2212 ;	gamelogic.c:505: matrixSet(snakePosX[i], snakePosY[i]);
   0944 EF                 2213 	mov	a,r7
   0945 24 80              2214 	add	a,#_snakePosX
   0947 F9                 2215 	mov	r1,a
   0948 87 82              2216 	mov	dpl,@r1
   094A EF                 2217 	mov	a,r7
   094B 24 C0              2218 	add	a,#_snakePosY
   094D F9                 2219 	mov	r1,a
   094E 87 08              2220 	mov	_matrixSet_PARM_2,@r1
   0950 C0 07              2221 	push	ar7
   0952 12 01 B2           2222 	lcall	_matrixSet
   0955 D0 07              2223 	pop	ar7
                           2224 ;	gamelogic.c:504: for(i=1;i<snakeLen;i++)
   0957 0F                 2225 	inc	r7
   0958 80 D1              2226 	sjmp	00142$
   095A                    2227 00145$:
                           2228 ;	gamelogic.c:507: if(snakePosX[0] == fruitX && snakePosY[0] == fruitY){
   095A 78 80              2229 	mov	r0,#_snakePosX
   095C E6                 2230 	mov	a,@r0
   095D FF                 2231 	mov	r7,a
   095E B5 39 2F           2232 	cjne	a,_fruitX,00133$
   0961 78 C0              2233 	mov	r0,#_snakePosY
   0963 E6                 2234 	mov	a,@r0
   0964 FF                 2235 	mov	r7,a
   0965 B5 3A 28           2236 	cjne	a,_fruitY,00133$
                           2237 ;	gamelogic.c:508: do{
   0968                    2238 00127$:
                           2239 ;	gamelogic.c:509: fruitX = getRandomNumber()>>5;
   0968 12 02 C6           2240 	lcall	_getRandomNumber
   096B E5 82              2241 	mov	a,dpl
   096D C4                 2242 	swap	a
   096E 03                 2243 	rr	a
   096F 54 07              2244 	anl	a,#0x07
   0971 F5 39              2245 	mov	_fruitX,a
                           2246 ;	gamelogic.c:510: fruitY = getRandomNumber()>>5;
   0973 12 02 C6           2247 	lcall	_getRandomNumber
   0976 E5 82              2248 	mov	a,dpl
   0978 C4                 2249 	swap	a
   0979 03                 2250 	rr	a
   097A 54 07              2251 	anl	a,#0x07
   097C F5 3A              2252 	mov	_fruitY,a
                           2253 ;	gamelogic.c:511: }while(matrixGet(fruitX, fruitY));
   097E 85 3A 08           2254 	mov	_matrixGet_PARM_2,_fruitY
   0981 85 39 82           2255 	mov	dpl,_fruitX
   0984 12 02 0A           2256 	lcall	_matrixGet
   0987 E5 82              2257 	mov	a,dpl
   0989 70 DD              2258 	jnz	00127$
                           2259 ;	gamelogic.c:512: score++;
   098B 05 41              2260 	inc	_score
                           2261 ;	gamelogic.c:513: snakeLen++;
   098D 05 3B              2262 	inc	_snakeLen
   098F 22                 2263 	ret
   0990                    2264 00133$:
                           2265 ;	gamelogic.c:515: if(matrixColPut(1, snakePosX[0], snakePosY[0])) return gameOver();
   0990 78 80              2266 	mov	r0,#_snakePosX
   0992 86 07              2267 	mov	ar7,@r0
   0994 8F 08              2268 	mov	_matrixColPut_PARM_2,r7
   0996 75 09 00           2269 	mov	(_matrixColPut_PARM_2 + 1),#0x00
   0999 78 C0              2270 	mov	r0,#_snakePosY
   099B 86 07              2271 	mov	ar7,@r0
   099D 8F 0A              2272 	mov	_matrixColPut_PARM_3,r7
   099F 75 0B 00           2273 	mov	(_matrixColPut_PARM_3 + 1),#0x00
   09A2 75 82 01           2274 	mov	dpl,#0x01
   09A5 12 02 28           2275 	lcall	_matrixColPut
   09A8 E5 82              2276 	mov	a,dpl
   09AA 60 03              2277 	jz	00146$
   09AC 02 02 D4           2278 	ljmp	_gameOver
   09AF                    2279 00146$:
   09AF 22                 2280 	ret
                           2281 ;------------------------------------------------------------
                           2282 ;Allocation info for local variables in function 'gameGuitar'
                           2283 ;------------------------------------------------------------
                           2284 ;	gamelogic.c:523: void gameGuitar()
                           2285 ;	-----------------------------------------
                           2286 ;	 function gameGuitar
                           2287 ;	-----------------------------------------
   09B0                    2288 _gameGuitar:
                           2289 ;	gamelogic.c:526: if(loop%10 == 0){
   09B0 75 08 0A           2290 	mov	__moduint_PARM_2,#0x0A
   09B3 75 09 00           2291 	mov	(__moduint_PARM_2 + 1),#0x00
   09B6 85 3F 82           2292 	mov	dpl,_loop
   09B9 85 40 83           2293 	mov	dph,(_loop + 1)
   09BC 12 0A D6           2294 	lcall	__moduint
   09BF E5 82              2295 	mov	a,dpl
   09C1 85 83 F0           2296 	mov	b,dph
   09C4 45 F0              2297 	orl	a,b
   09C6 70 57              2298 	jnz	00109$
                           2299 ;	gamelogic.c:527: if(song1Notes[currentNote] == ' '){
   09C8 E5 46              2300 	mov	a,_currentNote
   09CA 90 0C 1D           2301 	mov	dptr,#_song1Notes
   09CD 93                 2302 	movc	a,@a+dptr
   09CE FF                 2303 	mov	r7,a
   09CF BF 20 0E           2304 	cjne	r7,#0x20,00102$
                           2305 ;	gamelogic.c:528: soundStop();
   09D2 12 02 A5           2306 	lcall	_soundStop
                           2307 ;	gamelogic.c:529: currentNote++;
   09D5 05 46              2308 	inc	_currentNote
                           2309 ;	gamelogic.c:530: currentNote%=78;									
   09D7 75 F0 4E           2310 	mov	b,#0x4E
   09DA E5 46              2311 	mov	a,_currentNote
   09DC 84                 2312 	div	ab
   09DD 85 F0 46           2313 	mov	_currentNote,b
   09E0                    2314 00102$:
                           2315 ;	gamelogic.c:532: if(song1Notes[currentNote] != ' ')
   09E0 E5 46              2316 	mov	a,_currentNote
   09E2 90 0C 1D           2317 	mov	dptr,#_song1Notes
   09E5 93                 2318 	movc	a,@a+dptr
   09E6 FF                 2319 	mov	r7,a
   09E7 BF 20 02           2320 	cjne	r7,#0x20,00122$
   09EA 80 08              2321 	sjmp	00104$
   09EC                    2322 00122$:
                           2323 ;	gamelogic.c:533: soundPlay(song1Notes[currentNote]-'A');
   09EC EF                 2324 	mov	a,r7
   09ED 24 BF              2325 	add	a,#0xBF
   09EF F5 82              2326 	mov	dpl,a
   09F1 12 02 AA           2327 	lcall	_soundPlay
   09F4                    2328 00104$:
                           2329 ;	gamelogic.c:534: currentTiming++;
   09F4 05 47              2330 	inc	_currentTiming
                           2331 ;	gamelogic.c:536: if(currentTiming == song1Timing[currentNote]-'0'){
   09F6 E5 46              2332 	mov	a,_currentNote
   09F8 90 0C 38           2333 	mov	dptr,#_song1Timing
   09FB 93                 2334 	movc	a,@a+dptr
   09FC 7E 00              2335 	mov	r6,#0x00
   09FE 24 D0              2336 	add	a,#0xD0
   0A00 FF                 2337 	mov	r7,a
   0A01 EE                 2338 	mov	a,r6
   0A02 34 FF              2339 	addc	a,#0xFF
   0A04 FE                 2340 	mov	r6,a
   0A05 AC 47              2341 	mov	r4,_currentTiming
   0A07 7D 00              2342 	mov	r5,#0x00
   0A09 EC                 2343 	mov	a,r4
   0A0A B5 07 12           2344 	cjne	a,ar7,00109$
   0A0D ED                 2345 	mov	a,r5
   0A0E B5 06 0E           2346 	cjne	a,ar6,00109$
                           2347 ;	gamelogic.c:537: currentTiming = 0;
   0A11 75 47 00           2348 	mov	_currentTiming,#0x00
                           2349 ;	gamelogic.c:538: currentNote++;
   0A14 05 46              2350 	inc	_currentNote
                           2351 ;	gamelogic.c:539: currentNote%=62;					
   0A16 75 F0 3E           2352 	mov	b,#0x3E
   0A19 E5 46              2353 	mov	a,_currentNote
   0A1B 84                 2354 	div	ab
   0A1C 85 F0 46           2355 	mov	_currentNote,b
   0A1F                    2356 00109$:
   0A1F 22                 2357 	ret
                           2358 ;------------------------------------------------------------
                           2359 ;Allocation info for local variables in function 'gameLogic'
                           2360 ;------------------------------------------------------------
                           2361 ;	gamelogic.c:544: void gameLogic() __interrupt(TF1_VECTOR) __using(0)
                           2362 ;	-----------------------------------------
                           2363 ;	 function gameLogic
                           2364 ;	-----------------------------------------
   0A20                    2365 _gameLogic:
   0A20 C0 21              2366 	push	bits
   0A22 C0 E0              2367 	push	acc
   0A24 C0 F0              2368 	push	b
   0A26 C0 82              2369 	push	dpl
   0A28 C0 83              2370 	push	dph
   0A2A C0 07              2371 	push	(0+7)
   0A2C C0 06              2372 	push	(0+6)
   0A2E C0 05              2373 	push	(0+5)
   0A30 C0 04              2374 	push	(0+4)
   0A32 C0 03              2375 	push	(0+3)
   0A34 C0 02              2376 	push	(0+2)
   0A36 C0 01              2377 	push	(0+1)
   0A38 C0 00              2378 	push	(0+0)
   0A3A C0 D0              2379 	push	psw
   0A3C 75 D0 00           2380 	mov	psw,#0x00
                           2381 ;	gamelogic.c:546: if(state == STATE_LIST){
   0A3F E5 37              2382 	mov	a,_state
   0A41 70 05              2383 	jnz	00122$
                           2384 ;	gamelogic.c:547: gameList();
   0A43 12 03 6B           2385 	lcall	_gameList
   0A46 80 40              2386 	sjmp	00123$
   0A48                    2387 00122$:
                           2388 ;	gamelogic.c:548: }else if(state == STATE_GAMEOVER){
   0A48 74 01              2389 	mov	a,#0x01
   0A4A B5 37 0B           2390 	cjne	a,_state,00119$
                           2391 ;	gamelogic.c:549: if(BTN_UP || BTN_DOWN) state = STATE_LIST;
   0A4D 30 B4 03           2392 	jnb	_P3_4,00101$
   0A50 20 B2 35           2393 	jb	_P3_2,00123$
   0A53                    2394 00101$:
   0A53 75 37 00           2395 	mov	_state,#0x00
   0A56 80 30              2396 	sjmp	00123$
   0A58                    2397 00119$:
                           2398 ;	gamelogic.c:550: }else if(state == STATE_TETRIS){	
   0A58 74 02              2399 	mov	a,#0x02
   0A5A B5 37 05           2400 	cjne	a,_state,00116$
                           2401 ;	gamelogic.c:551: gameTetris();
   0A5D 12 04 A9           2402 	lcall	_gameTetris
   0A60 80 26              2403 	sjmp	00123$
   0A62                    2404 00116$:
                           2405 ;	gamelogic.c:552: }else if(state == STATE_CAR){
   0A62 74 03              2406 	mov	a,#0x03
   0A64 B5 37 05           2407 	cjne	a,_state,00113$
                           2408 ;	gamelogic.c:553: gameCar();
   0A67 12 06 00           2409 	lcall	_gameCar
   0A6A 80 1C              2410 	sjmp	00123$
   0A6C                    2411 00113$:
                           2412 ;	gamelogic.c:554: }else if(state == STATE_CHOPPER){
   0A6C 74 04              2413 	mov	a,#0x04
   0A6E B5 37 05           2414 	cjne	a,_state,00110$
                           2415 ;	gamelogic.c:555: gameChopper();
   0A71 12 06 F9           2416 	lcall	_gameChopper
   0A74 80 12              2417 	sjmp	00123$
   0A76                    2418 00110$:
                           2419 ;	gamelogic.c:556: }else if(state == STATE_SNAKE){
   0A76 74 05              2420 	mov	a,#0x05
   0A78 B5 37 05           2421 	cjne	a,_state,00107$
                           2422 ;	gamelogic.c:557: gameSnake();
   0A7B 12 08 56           2423 	lcall	_gameSnake
   0A7E 80 08              2424 	sjmp	00123$
   0A80                    2425 00107$:
                           2426 ;	gamelogic.c:558: }else if(state == STATE_GUITAR){
   0A80 74 06              2427 	mov	a,#0x06
   0A82 B5 37 03           2428 	cjne	a,_state,00123$
                           2429 ;	gamelogic.c:559: gameGuitar();
   0A85 12 09 B0           2430 	lcall	_gameGuitar
   0A88                    2431 00123$:
                           2432 ;	gamelogic.c:563: loop++;
   0A88 05 3F              2433 	inc	_loop
   0A8A E4                 2434 	clr	a
   0A8B B5 3F 02           2435 	cjne	a,_loop,00157$
   0A8E 05 40              2436 	inc	(_loop + 1)
   0A90                    2437 00157$:
                           2438 ;	gamelogic.c:566: TL1 = (0xFFFF-GAMELOGIC_US) & 0xFF;
   0A90 75 8B DF           2439 	mov	_TL1,#0xDF
                           2440 ;	gamelogic.c:567: TH1 = (0xFFFF-GAMELOGIC_US) >> 8; 
   0A93 75 8D B1           2441 	mov	_TH1,#0xB1
   0A96 D0 D0              2442 	pop	psw
   0A98 D0 00              2443 	pop	(0+0)
   0A9A D0 01              2444 	pop	(0+1)
   0A9C D0 02              2445 	pop	(0+2)
   0A9E D0 03              2446 	pop	(0+3)
   0AA0 D0 04              2447 	pop	(0+4)
   0AA2 D0 05              2448 	pop	(0+5)
   0AA4 D0 06              2449 	pop	(0+6)
   0AA6 D0 07              2450 	pop	(0+7)
   0AA8 D0 83              2451 	pop	dph
   0AAA D0 82              2452 	pop	dpl
   0AAC D0 F0              2453 	pop	b
   0AAE D0 E0              2454 	pop	acc
   0AB0 D0 21              2455 	pop	bits
   0AB2 32                 2456 	reti
                           2457 ;------------------------------------------------------------
                           2458 ;Allocation info for local variables in function 'main'
                           2459 ;------------------------------------------------------------
                           2460 ;	proyecto.c:12: void main()
                           2461 ;	-----------------------------------------
                           2462 ;	 function main
                           2463 ;	-----------------------------------------
   0AB3                    2464 _main:
                           2465 ;	proyecto.c:14: SOUND_PIN = 0;
   0AB3 C2 B7              2466 	clr	_P3_7
                           2467 ;	proyecto.c:15: IT0 = 1;
   0AB5 D2 88              2468 	setb	_IT0
                           2469 ;	proyecto.c:16: IT1 = 1;
   0AB7 D2 8A              2470 	setb	_IT1
                           2471 ;	proyecto.c:19: IE = 0x80;
   0AB9 75 A8 80           2472 	mov	_IE,#0x80
                           2473 ;	proyecto.c:20: ET0 = 1;
   0ABC D2 A9              2474 	setb	_ET0
                           2475 ;	proyecto.c:21: ET1 = 1;
   0ABE D2 AB              2476 	setb	_ET1
                           2477 ;	proyecto.c:22: EX0 = 1;
   0AC0 D2 A8              2478 	setb	_EX0
                           2479 ;	proyecto.c:23: EX1 = 1;
   0AC2 D2 AA              2480 	setb	_EX1
                           2481 ;	proyecto.c:27: PT2=1;
   0AC4 D2 BD              2482 	setb	_PT2
                           2483 ;	proyecto.c:30: TMOD = T0_M0 | T1_M0;
   0AC6 75 89 11           2484 	mov	_TMOD,#0x11
                           2485 ;	proyecto.c:31: TR0 = 1;
   0AC9 D2 8C              2486 	setb	_TR0
                           2487 ;	proyecto.c:32: TR2 = 1;
   0ACB D2 CA              2488 	setb	_TR2
                           2489 ;	proyecto.c:35: T2CON_0 = 0;	
   0ACD C2 C8              2490 	clr	_T2CON_0
                           2491 ;	proyecto.c:38: matrixSets();
   0ACF 12 01 68           2492 	lcall	_matrixSets
                           2493 ;	proyecto.c:41: TR1 = 1;
   0AD2 D2 8E              2494 	setb	_TR1
                           2495 ;	proyecto.c:43: while(1);
   0AD4                    2496 00102$:
   0AD4 80 FE              2497 	sjmp	00102$
                           2498 	.area CSEG    (CODE)
                           2499 	.area CONST   (CODE)
   0B27                    2500 _matrixTranslationY:
   0B27 03                 2501 	.db #0x03	; 3
   0B28 02                 2502 	.db #0x02	; 2
   0B29 01                 2503 	.db #0x01	; 1
   0B2A 00                 2504 	.db #0x00	; 0
   0B2B 07                 2505 	.db #0x07	; 7
   0B2C 06                 2506 	.db #0x06	; 6
   0B2D 05                 2507 	.db #0x05	; 5
   0B2E 04                 2508 	.db #0x04	; 4
   0B2F                    2509 _soundNotes:
   0B2F 8E FB              2510 	.byte #0x8E,#0xFB	; 64398
   0B31 08 FC              2511 	.byte #0x08,#0xFC	; 64520
   0B33 42 FC              2512 	.byte #0x42,#0xFC	; 64578
   0B35 AB FC              2513 	.byte #0xAB,#0xFC	; 64683
   0B37 08 FD              2514 	.byte #0x08,#0xFD	; 64776
   0B39 32 FD              2515 	.byte #0x32,#0xFD	; 64818
   0B3B 80 FD              2516 	.byte #0x80,#0xFD	; 64896
   0B3D C6 FD              2517 	.byte #0xC6,#0xFD	; 64966
   0B3F 03 FE              2518 	.byte #0x03,#0xFE	; 65027
   0B41 20 FE              2519 	.byte #0x20,#0xFE	; 65056
   0B43 55 FE              2520 	.byte #0x55,#0xFE	; 65109
   0B45 83 FE              2521 	.byte #0x83,#0xFE	; 65155
   0B47 98 FE              2522 	.byte #0x98,#0xFE	; 65176
   0B49 BF FE              2523 	.byte #0xBF,#0xFE	; 65215
   0B4B 5B FD              2524 	.byte #0x5B,#0xFD	; 64859
   0B4D                    2525 _song:
   0B4D 45 42 43 44 43 42  2526 	.ascii "EBCDCB AACEDC BBCDE CAA   DFHH  GFEECE EDCBBC DDECA A  EC DB"
        20 41 41 43 45 44
        43 20 42 42 43 44
        45 20 43 41 41 20
        20 20 44 46 48 48
        20 20 47 46 45 45
        43 45 20 45 44 43
        42 42 43 20 44 44
        45 43 41 20 41 20
        20 45 43 20 44 42
   0B89 20 43 41 20 41 42  2527 	.ascii " CA AB EC DB CEH H"
        20 45 43 20 44 42
        20 43 45 48 20 48
   0B9B 00                 2528 	.db 0x00
   0B9C                    2529 _timing:
   0B9C 32 31 31 32 31 31  2530 	.ascii "211211 211211 21122 2222 221211 112211 211121 21221 22 44 44"
        20 32 31 31 32 31
        31 20 32 31 31 32
        32 20 32 32 32 32
        20 32 32 31 32 31
        31 20 31 31 32 32
        31 31 20 32 31 31
        31 32 31 20 32 31
        32 32 31 20 32 32
        20 34 34 20 34 34
   0BD8 20 34 34 20 34 34  2531 	.ascii " 44 44 44 44 224 8"
        20 34 34 20 34 34
        20 32 32 34 20 38
   0BEA 00                 2532 	.db 0x00
   0BEB                    2533 _fuente:
   0BEB 02                 2534 	.db #0x02	; 2
   0BEC 05                 2535 	.db #0x05	; 5
   0BED 05                 2536 	.db #0x05	; 5
   0BEE 05                 2537 	.db #0x05	; 5
   0BEF 02                 2538 	.db #0x02	; 2
   0BF0 01                 2539 	.db #0x01	; 1
   0BF1 03                 2540 	.db #0x03	; 3
   0BF2 01                 2541 	.db #0x01	; 1
   0BF3 01                 2542 	.db #0x01	; 1
   0BF4 01                 2543 	.db #0x01	; 1
   0BF5 06                 2544 	.db #0x06	; 6
   0BF6 01                 2545 	.db #0x01	; 1
   0BF7 02                 2546 	.db #0x02	; 2
   0BF8 04                 2547 	.db #0x04	; 4
   0BF9 07                 2548 	.db #0x07	; 7
   0BFA 06                 2549 	.db #0x06	; 6
   0BFB 01                 2550 	.db #0x01	; 1
   0BFC 02                 2551 	.db #0x02	; 2
   0BFD 01                 2552 	.db #0x01	; 1
   0BFE 06                 2553 	.db #0x06	; 6
   0BFF 01                 2554 	.db #0x01	; 1
   0C00 03                 2555 	.db #0x03	; 3
   0C01 05                 2556 	.db #0x05	; 5
   0C02 07                 2557 	.db #0x07	; 7
   0C03 01                 2558 	.db #0x01	; 1
   0C04 07                 2559 	.db #0x07	; 7
   0C05 04                 2560 	.db #0x04	; 4
   0C06 07                 2561 	.db #0x07	; 7
   0C07 01                 2562 	.db #0x01	; 1
   0C08 06                 2563 	.db #0x06	; 6
   0C09 02                 2564 	.db #0x02	; 2
   0C0A 04                 2565 	.db #0x04	; 4
   0C0B 06                 2566 	.db #0x06	; 6
   0C0C 05                 2567 	.db #0x05	; 5
   0C0D 02                 2568 	.db #0x02	; 2
   0C0E 07                 2569 	.db #0x07	; 7
   0C0F 01                 2570 	.db #0x01	; 1
   0C10 02                 2571 	.db #0x02	; 2
   0C11 02                 2572 	.db #0x02	; 2
   0C12 02                 2573 	.db #0x02	; 2
   0C13 02                 2574 	.db #0x02	; 2
   0C14 05                 2575 	.db #0x05	; 5
   0C15 02                 2576 	.db #0x02	; 2
   0C16 05                 2577 	.db #0x05	; 5
   0C17 02                 2578 	.db #0x02	; 2
   0C18 02                 2579 	.db #0x02	; 2
   0C19 05                 2580 	.db #0x05	; 5
   0C1A 07                 2581 	.db #0x07	; 7
   0C1B 01                 2582 	.db #0x01	; 1
   0C1C 06                 2583 	.db #0x06	; 6
   0C1D                    2584 _song1Notes:
   0C1D 44 4B 41 47 4E 41  2585 	.ascii "DKAGNAOA EKAGNAOA GKAGNAOA"
        4F 41 20 45 4B 41
        47 4E 41 4F 41 20
        47 4B 41 47 4E 41
        4F 41
   0C37 00                 2586 	.db 0x00
   0C38                    2587 _song1Timing:
   0C38 31 31 31 31 31 31  2588 	.ascii "11111111 11111111 11111111"
        31 31 20 31 31 31
        31 31 31 31 31 20
        31 31 31 31 31 31
        31 31
   0C52 00                 2589 	.db 0x00
                           2590 	.area XINIT   (CODE)
                           2591 	.area CABS    (ABS,CODE)
