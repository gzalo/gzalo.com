#include <stdio.h>
#include <stdlib.h>

#define LISTA1 6
#define LISTA2 4
typedef struct Alumno t_nodo;

struct Alumno
{
    char nombre[20];
    int nota;
    t_nodo *sig;
    t_nodo *prox2;
};

void mostrarporsig(t_nodo *primnodo)
{
    if(primnodo==NULL) return;
    if(primnodo->sig==NULL) return;
    printf("%s: %d -s> ",primnodo->nombre,primnodo->nota);
    mostrarporsig(primnodo->sig);
}

t_nodo *buscar2(t_nodo *desdeaca)
{
    if(desdeaca==NULL)return(desdeaca);
    if(desdeaca->nota == 2) return(desdeaca);
    if(desdeaca->sig == NULL) return(NULL);
    return (buscar2(desdeaca->sig));
}
void mostrarporprox(t_nodo *primnodo)
{
    if(primnodo==NULL) return;
    printf("%s: %d -p> ",primnodo->nombre,primnodo->nota);
    if(primnodo->prox2==NULL) return;
    mostrarporprox(primnodo->prox2);
}

void enganchar2(t_nodo **primer2,t_nodo **materias)
{
    int i=0;
    t_nodo *aux;
    while(materias[i] != NULL)//busco el primer 2
    {
        *primer2=buscar2(materias[i]);
        if(*primer2 != NULL) break;
        i++;
    }//____________________________________________


    aux=*primer2;


    while(materias[i]!=NULL)
    {
        aux->prox2=buscar2(aux->sig);
        if(aux->prox2!=NULL)
        {
            aux->prox2=buscar2(aux->sig);
            aux=aux->prox2;
        }
        else
        {
        i++;
        aux->sig=buscar2(materias[i]);
        }
//continue;//paso al renglón siguiente pero me quedo en el mismo nodo.
    }





}

int main()
{
    FILE *fp;
    int i;
    t_nodo *materias[4],*aux,* primer2;
    fp=fopen("Lista_alumnos.txt","r");

    materias[0]=malloc(sizeof(t_nodo));
    materias[1]=malloc(sizeof(t_nodo));
    materias[2]=NULL;
    aux=materias[0];
    for(i=0; i<LISTA1; i++)
    {
        fscanf(fp,"%s %d\n",aux->nombre,&(aux->nota));
        aux->sig=malloc(sizeof(t_nodo));
        aux->sig->sig=NULL;
        aux=aux->sig;
    }
    aux=materias[1];
    for(i=0; i<LISTA2; i++)
    {
        fscanf(fp,"%s %d\n",aux->nombre,&(aux->nota));
        aux->sig=malloc(sizeof(t_nodo));
        aux->sig->sig=NULL;
        aux=aux->sig;
    }

    mostrarporsig(materias[0]);
    puts(" ");
    mostrarporsig(materias[1]);
    enganchar2(&primer2,materias);

    puts(" ");
    puts("-----------------------");
    mostrarporprox(primer2);

    fclose(fp);
    return 0;
}
