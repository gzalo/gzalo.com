#include <stdio.h>
#include <stdlib.h>

#define TAM_VEC 10

int* pos_min(int cant, int * vec,int * posmin){// devuelve la posicion del menor valor que encuentra, va guardando el minimo en valor.
if (cant==0) return(posmin);
if(vec[0]< *posmin)
{
posmin=vec;
return(pos_min(cant-1, (vec+1),posmin));
}
return(pos_min(cant-1, (vec+1),posmin));
}

void Ordenar_recu(int cant, int *vec){
int *aux_ptr,aux;
if(cant != 1){
aux_ptr=pos_min(cant,vec,vec);
aux=*aux_ptr;
*aux_ptr=*vec;
*vec=aux;
Ordenar_recu(cant-1,vec+1);
}
return;
}
int main()
{
    srand (getpid());
    printf("Hello world!\n");
    int vector[TAM_VEC],cant = TAM_VEC,i;

 for (i=0;i<cant;i++)
 {
 vector[i]=rand()%100;
 printf(" %d\n",vector[i]);
 }
 Ordenar_recu(cant,vector);

 puts("-------------------------------");
  for (i=0;i<cant;i++)
 {
 printf(" %d\n",vector[i]);
 }
    return 0;
}
