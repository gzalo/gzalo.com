#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

#define KNRM  "\x1B[0m"
#define KRED  "\x1B[31m"
#define KGRN  "\x1B[32m"
#define KYEL  "\x1B[33m"
#define KBLU  "\x1B[34m"
#define KMAG  "\x1B[35m"
#define KCYN  "\x1B[36m"
#define KWHT  "\x1B[37m"


#define TAM_VEC 1000


int Ordenar_quick(int cant, int * vec)
{
    int pivot,i,j,aux;
    i=1;
    j=0;
    pivot=*vec; // Pivote el primer elemento.
    if (cant<2) return(0);//vuelvo si se termino
	if (cant==2){
	if(vec[0] > vec[1]){
	aux=vec[0];
        vec[0]=vec[1];
        vec[1]=aux;
	}
	return (0);
	}
    while(i<=cant-1-j)
    {
        if (vec[i]<=pivot && vec[cant-1-j]>=pivot)
        {
            i++;
            j++;
	continue;
        }
        if (vec[i]<pivot && vec[cant-1-j]<=pivot)
        {
            i++;
	continue;
        }
        if (vec[i]>pivot && vec[cant-1-j]>pivot)
        {
            j++;
	continue;
        }
        if (vec[i]>=pivot && vec[cant-1-j]<=pivot)
        {
            aux=vec[i];
            vec[i]=vec[cant-1-j];
            vec[cant-1-j]=aux;
            i++;
            j++;
	continue;
        }
	fprintf(stderr," i:%d j:%d cant:%d pivot:%d %d %d \t",i,j,cant,pivot,vec[i],vec[cant-1-j]);
	break;
     }
    if(i>=cant-j)
    {
        aux=vec[0];
        vec[0]=vec[cant-1-j];
        vec[cant-1-j]=aux;
    }
//fprintf(stderr,"| i:%d j:%d cant:%d %d %d |\t",i,j,cant,vec[i],vec[cant-1-j]);
//getchar();
//printf("A");
   Ordenar_quick(i-1,vec);
//printf("B");
   Ordenar_quick(cant-i,&vec[i]);
}

int main()
{
    char COLOR[10]= {KGRN};
    srand (getpid());
    int pivo;
    printf("Hello world!\n");
    int vector[TAM_VEC],cant = TAM_VEC,i;

    for (i=0; i<cant; i++)
    {
        vector[i]=rand()%100;
        if(vector[i]>vector[0])
        {
            strcpy(COLOR,KRED);
        }
        else
        {
            strcpy(COLOR,KGRN);
        }
        fprintf(stderr," %s%d ", COLOR,vector[i]);
    }

    pivo=vector[0];
    Ordenar_quick(cant,vector);

    printf("------>");
    for (i=0; i<cant; i++)
    {
        if(vector[i]>pivo)
        {
            strcpy(COLOR,KRED);
        }
        else
        {
            strcpy(COLOR,KGRN);
        }
        printf(" %s%d ", COLOR,vector[i]);
    }
	puts(" ");
    return 0;
}
